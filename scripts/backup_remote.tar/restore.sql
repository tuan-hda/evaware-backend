--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.3 (Ubuntu 15.3-1.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE examify_pxac;
--
-- Name: examify_pxac; Type: DATABASE; Schema: -; Owner: examify_pxac_user
--

CREATE DATABASE examify_pxac WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.UTF8';


ALTER DATABASE examify_pxac OWNER TO examify_pxac_user;

\connect examify_pxac

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: examify_pxac; Type: DATABASE PROPERTIES; Schema: -; Owner: examify_pxac_user
--

ALTER DATABASE examify_pxac SET "TimeZone" TO 'utc';


\connect examify_pxac

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: examify_pxac_user
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO examify_pxac_user;

--
-- Name: check_answer(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.check_answer(arg_examtaking_id integer, arg_question_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		var_user_answer int;
		var_correct_answer int;
	BEGIN		
		SELECT choice_id INTO var_user_answer
		FROM answer_record 
		WHERE exam_taking_id = arg_examtaking_id
		AND question_id = arg_question_id;
		
		SELECT choice_id INTO var_correct_answer
		FROM choice
		WHERE question_id = arg_question_id
		AND key = true;
		
-- 		Check user answer and correct answer: (0: wrong, 1: correct, 2: user don't filled)
		IF var_user_answer = var_correct_answer 
			THEN return 1;
		ELSE 
			IF var_user_answer <> var_correct_answer 
				THEN return 0;
			ELSE 
				return 2;
			END IF;
		END IF;
	END;
$$;


ALTER FUNCTION public.check_answer(arg_examtaking_id integer, arg_question_id integer) OWNER TO examify_pxac_user;

--
-- Name: check_completed_lesson(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.check_completed_lesson(arg_user_id integer, arg_lesson_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		completed boolean;
	BEGIN		
		SELECT CASE WHEN COUNT(*) = 0 THEN false ELSE true END INTO completed
		FROM join_lesson
		WHERE student_id = arg_user_id
		AND lesson_id = arg_lesson_id;

		RETURN completed;
	END;
$$;


ALTER FUNCTION public.check_completed_lesson(arg_user_id integer, arg_lesson_id integer) OWNER TO examify_pxac_user;

--
-- Name: check_flashcard_permission(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.check_flashcard_permission(arg_user_id integer, arg_fc_set_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		isAllow boolean;
	BEGIN
		SELECT CASE 
			WHEN 
				EXISTS (
					SELECT 1 FROM flashcard_share_permit 
					WHERE fc_set_id = arg_fc_set_id AND user_id = arg_user_id
				) 
				OR 
				EXISTS (                                                                       
					SELECT 1 FROM flashcard_set
					WHERE fc_set_id = arg_fc_set_id AND (created_by = arg_user_id OR access = 'public' OR system_belong = TRUE)
				)
			THEN true ELSE false 
		END INTO isAllow;

		RETURN isAllow;
	END;
$$;


ALTER FUNCTION public.check_flashcard_permission(arg_user_id integer, arg_fc_set_id integer) OWNER TO examify_pxac_user;

--
-- Name: check_join_course(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.check_join_course(arg_user_id integer, arg_course_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		isJoin boolean;
	BEGIN		
		SELECT CASE WHEN TEM.course_id = course.course_id THEN true ELSE false END INTO isJoin
		FROM course
		LEFT JOIN (
		  SELECT course_id 
		  FROM join_course
		  WHERE student_id = arg_user_id
		) AS TEM ON course.course_id = TEM.course_id
		WHERE course.course_id = arg_course_id;

		RETURN isJoin;
	END;
$$;


ALTER FUNCTION public.check_join_course(arg_user_id integer, arg_course_id integer) OWNER TO examify_pxac_user;

--
-- Name: decrease_total_chapter(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.decrease_total_chapter() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
-- 	Trigger:
	UPDATE course SET total_chapter = (total_chapter - 1) WHERE course_id = OLD.course_id;
	
	RAISE NOTICE 'Updated total chapter in course!';
	RETURN OLD;
END;

$$;


ALTER FUNCTION public.decrease_total_chapter() OWNER TO examify_pxac_user;

--
-- Name: decrease_total_exam(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.decrease_total_exam() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE exam_series SET total_exam = total_exam - 1 WHERE OLD.exam_series_id = exam_series_id;

	RAISE NOTICE 'Auto decrease total_exam successfully';
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.decrease_total_exam() OWNER TO examify_pxac_user;

--
-- Name: decrease_total_lesson(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.decrease_total_lesson() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
#variable_conflict use_variable
DECLARE var_unit_id INTEGER;
DECLARE var_chapter_id INTEGER;
DECLARE var_course_id INTEGER;
BEGIN
	var_unit_id := OLD.unit_id; 
	SELECT chapter_id INTO var_chapter_id FROM unit WHERE unit_id = var_unit_id;
	SELECT course_id INTO var_course_id FROM chapter WHERE chapter_id = var_chapter_id;
-- 	Trigger:
	UPDATE unit SET total_lesson = (total_lesson - 1) WHERE unit_id = var_unit_id;
	UPDATE chapter SET total_lesson = (total_lesson - 1) WHERE chapter_id = var_chapter_id;
	UPDATE course SET total_lesson = (total_lesson - 1) WHERE course_id = var_course_id;
	
	RAISE NOTICE 'Updated total lesson in unit, chapter and course!';
	RETURN NEW;
END;

$$;


ALTER FUNCTION public.decrease_total_lesson() OWNER TO examify_pxac_user;

--
-- Name: decrease_total_video_course(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.decrease_total_video_course() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
#variable_conflict use_variable
DECLARE var_type SMALLINT;
DECLARE var_video_time INTEGER;
DECLARE var_course_id INTEGER;
BEGIN
	var_type:= OLD.type;
	var_video_time:= OLD.video_time;
	--check
	IF var_type = 1 AND var_video_time != 0 THEN
		SELECT chapter.course_id INTO var_course_id
		FROM chapter, unit
		WHERE unit.unit_id = OLD.unit_id
		AND unit.chapter_id = chapter.chapter_id;
	--Trigger	
		UPDATE course 
		SET total_video_time = total_video_time - var_video_time
		WHERE  course_id = var_course_id;
	--Notice	
		RAISE NOTICE 'Updated total video time in course!';
	END IF;
	RETURN NULL;
END
$$;


ALTER FUNCTION public.decrease_total_video_course() OWNER TO examify_pxac_user;

--
-- Name: fn_check_user_like(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_check_user_like(arg_user_id integer, arg_comment_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		isExist boolean;
	BEGIN
		SELECT CASE WHEN user_id = arg_user_id AND comment_id = arg_comment_id THEN true ELSE false END INTO isExist
		FROM likes
		WHERE user_id = arg_user_id AND comment_id = arg_comment_id;
		
		RETURN isExist;
	END;
$$;


ALTER FUNCTION public.fn_check_user_like(arg_user_id integer, arg_comment_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_create_a_role_user(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_create_a_role_user() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		INSERT INTO user_to_role(user_id, role_id) VALUES(NEW.user_id, 4);
		RAISE NOTICE 'Create a new user_to_role for user!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_create_a_role_user() OWNER TO examify_pxac_user;

--
-- Name: fn_create_update_rating_course(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_create_update_rating_course() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_course_id INTEGER;
DECLARE var_quatity_rating INTEGER;
DECLARE var_avg_rating NUMERIC(3,2);
	BEGIN
		var_course_id:= NEW.course_id;
		IF EXISTS (SELECT 1 FROM rating WHERE course_id = var_course_id) THEN
			SELECT COUNT(*), AVG(rating.rate) INTO var_quatity_rating, var_avg_rating
			FROM rating
			WHERE rating.course_id = var_course_id;
		
			UPDATE course 
			SET quantity_rating = var_quatity_rating, avg_rating = var_avg_rating
			WHERE course_id = var_course_id;
		ELSE
			UPDATE course 
			SET quantity_rating = 0, avg_rating = 0
			WHERE course_id = var_course_id;
		END IF;
			RAISE NOTICE'Updated quantity rating and average rating!';
	RETURN NULL;
	END
$$;


ALTER FUNCTION public.fn_create_update_rating_course() OWNER TO examify_pxac_user;

--
-- Name: fn_decrease_total_part_exam(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_decrease_total_part_exam() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		UPDATE exam SET total_part = total_part - 1 WHERE exam_id = OLD.exam_id;
		RAISE NOTICE 'Updated total_part in exam!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_decrease_total_part_exam() OWNER TO examify_pxac_user;

--
-- Name: fn_decrease_total_question_exam(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_decrease_total_question_exam() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_exam_id INT;
	BEGIN
		SELECT part.exam_id INTO var_exam_id
		FROM set_question, part
		WHERE set_question.part_id = part.part_id
		AND set_question.set_question_id = OLD.set_question_id;
-- 		decrement total_question
		UPDATE exam SET total_question = total_question - 1 WHERE exam_id = var_exam_id;
		
		RAISE NOTICE 'Updated total_question in exam!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_decrease_total_question_exam() OWNER TO examify_pxac_user;

--
-- Name: fn_decrease_total_question_part(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_decrease_total_question_part() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_part_id INT;
	BEGIN
		SELECT set_question.part_id INTO var_part_id
		FROM set_question
		WHERE set_question.set_question_id = OLD.set_question_id;
-- 		decrement total_question
		UPDATE part SET total_question = total_question - 1 WHERE part_id = var_part_id;
		
		RAISE NOTICE 'Updated total_question in part!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_decrease_total_question_part() OWNER TO examify_pxac_user;

--
-- Name: fn_delete_chapter(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_chapter(arg_chapter_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT unit_id
			FROM unit
			WHERE chapter_id = arg_chapter_id
		 LOOP
			PERFORM fn_delete_unit(var_recode.unit_id);
		END LOOP;
		
		DELETE FROM chapter where chapter_id = arg_chapter_id;
		RAISE NOTICE 'Delete chapter success!';
	END;
$$;


ALTER FUNCTION public.fn_delete_chapter(arg_chapter_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_choice(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_choice(arg_choice_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
-- 		Delete answer_record reference:
		DELETE FROM answer_record WHERE choice_id = arg_choice_id;
-- 		Delete Choice:
		DELETE FROM choice WHERE choice_id = arg_choice_id;
 			RAISE NOTICE 'Deleted choice!';
	END;
$$;


ALTER FUNCTION public.fn_delete_choice(arg_choice_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_comment(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_comment(arg_comment_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
	BEGIN
-- 		Detete all relationship 
		DELETE FROM likes where comment_id = arg_comment_id;
-- 		Delete comment
		DELETE FROM comment where comment_id = arg_comment_id;
		
		RAISE NOTICE 'Delete comment success!';
	END;
$$;


ALTER FUNCTION public.fn_delete_comment(arg_comment_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_course(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_course(arg_course_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
-- 	Delete comment reference
		FOR var_recode IN 
			SELECT comment_id
			FROM comment
			WHERE course_id = arg_course_id
		 LOOP
			PERFORM fn_delete_comment(var_recode.comment_id);
		END LOOP;
-- 	Delete Join_course reference
		DELETE FROM join_course WHERE course_id = arg_course_id;
-- 	Delete Raing reference
		DELETE FROM rating WHERE course_id = arg_course_id;
-- 	Delete chapter reference
		FOR var_recode IN 
			SELECT chapter_id
			FROM chapter
			WHERE course_id = arg_course_id
		 LOOP
			PERFORM fn_delete_chapter(var_recode.chapter_id);
		END LOOP;
		
		DELETE FROM course WHERE course_id = arg_course_id;
		RAISE NOTICE 'Delete course success!';
	END;
$$;


ALTER FUNCTION public.fn_delete_course(arg_course_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_exam(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_exam(arg_exam_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
-- 		Delete part reference:
		FOR var_recode IN 
			SELECT part_id
			FROM part
			WHERE part.exam_id = arg_exam_id
		 LOOP
			PERFORM fn_delete_part(var_recode.part_id);
		END LOOP;
-- 		Delete exam taking reference:
		DELETE FROM exam_taking WHERE exam_id = arg_exam_id;

-- 		Delete exam:
		DELETE FROM exam WHERE exam_id = arg_exam_id;
		RAISE NOTICE 'Deleted exam!';
	END;
$$;


ALTER FUNCTION public.fn_delete_exam(arg_exam_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_exam_series(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_exam_series(arg_exam_series_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
-- 		Delete exam reference:
		FOR var_recode IN 
			SELECT exam_id
			FROM exam
			WHERE exam.exam_series_id = arg_exam_series_id
		 LOOP
			PERFORM fn_delete_exam(var_recode.exam_id);
		END LOOP;

-- 		Delete exam series:
		DELETE FROM exam_series WHERE exam_series_id = arg_exam_series_id;
		RAISE NOTICE 'Deleted exam series!';
	END;
$$;


ALTER FUNCTION public.fn_delete_exam_series(arg_exam_series_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_lesson(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_lesson(arg_lesson_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
	BEGIN
		-- Delete all relationship
		DELETE FROM note WHERE lesson_id = arg_lesson_id;
		DELETE FROM slide WHERE lesson_id = arg_lesson_id;
		DELETE FROM join_lesson WHERE lesson_id = arg_lesson_id;
		-- Delete lesson
		DELETE FROM lesson where lesson_id = arg_lesson_id;
		RAISE NOTICE 'Deleted lesson success!';
	END;
$$;


ALTER FUNCTION public.fn_delete_lesson(arg_lesson_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_part(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_part(arg_part_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
-- 		Delete set question reference:
		FOR var_recode IN 
			SELECT set_question_id
			FROM set_question
			WHERE set_question.part_id = arg_part_id
		 LOOP
			PERFORM fn_delete_set_question(var_recode.set_question_id);
		END LOOP;
-- 		Delete part option reference:
		DELETE FROM part_option WHERE part_id = arg_part_id;

-- 		Delete part:
		DELETE FROM part WHERE part_id = arg_part_id;
		RAISE NOTICE 'Deleted part!';
	END;
$$;


ALTER FUNCTION public.fn_delete_part(arg_part_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_question(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_question(arg_question_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
-- 		Delete choice reference:
		FOR var_recode IN 
			SELECT choice_id
			FROM choice
			WHERE choice.question_id = arg_question_id
		 LOOP
			PERFORM fn_delete_choice(var_recode.choice_id);
		END LOOP;
-- 		Delete question:
		DELETE FROM question WHERE question_id = arg_question_id;
		RAISE NOTICE 'Deleted question!';
	END;
$$;


ALTER FUNCTION public.fn_delete_question(arg_question_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_rating_course(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_rating_course() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_course_id INTEGER;
DECLARE var_quatity_rating INTEGER;
DECLARE var_avg_rating NUMERIC(3,2);
	BEGIN
		var_course_id:= OLD.course_id;
		IF EXISTS (SELECT 1 FROM rating WHERE course_id = var_course_id) THEN
			SELECT COUNT(*), AVG(rating.rate) INTO var_quatity_rating, var_avg_rating
			FROM rating
			WHERE rating.course_id = var_course_id;
		
			UPDATE course 
			SET quantity_rating = var_quatity_rating, avg_rating = var_avg_rating
			WHERE course_id = var_course_id;
		ELSE
			UPDATE course 
			SET quantity_rating = 0, avg_rating = 0
			WHERE course_id = var_course_id;
		END IF;
			RAISE NOTICE'Updated quantity rating and average rating!';
	RETURN NULL;
	END
$$;


ALTER FUNCTION public.fn_delete_rating_course() OWNER TO examify_pxac_user;

--
-- Name: fn_delete_set_question(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_set_question(arg_set_question_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode_question RECORD;
DECLARE var_recode_side RECORD;
	BEGIN
-- 		Delete question reference:
		FOR var_recode_question IN 
			SELECT question_id
			FROM question
			WHERE question.set_question_id = arg_set_question_id
		 LOOP
			PERFORM fn_delete_question(var_recode_question.question_id);
		END LOOP;
-- 		Delete side reference:
		DELETE FROM side WHERE set_question_id = arg_set_question_id;

-- 		Delete set question:
		DELETE FROM set_question WHERE set_question_id = arg_set_question_id;
		RAISE NOTICE 'Deleted set question!';
	END;
$$;


ALTER FUNCTION public.fn_delete_set_question(arg_set_question_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_delete_unit(integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_delete_unit(arg_unit_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT lesson_id
			FROM lesson
			WHERE unit_id = arg_unit_id
		 LOOP
			PERFORM fn_delete_lesson(var_recode.lesson_id);
		END LOOP;
		
		DELETE FROM unit where unit_id = arg_unit_id;
		RAISE NOTICE 'Delete unit success!';
	END;
$$;


ALTER FUNCTION public.fn_delete_unit(arg_unit_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_enroll_course(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_enroll_course(arg_user_id integer, arg_course_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE var_accumulated_point INTEGER;
DECLARE var_point_to_unlock INTEGER;
	BEGIN
		SELECT accumulated_point 
		INTO var_accumulated_point
		FROM users WHERE user_id = arg_user_id;
		
		SELECT point_to_unlock 
		INTO var_point_to_unlock
		FROM course WHERE course_id = arg_course_id;
		
		IF var_accumulated_point >= var_point_to_unlock THEN
			INSERT INTO join_course 
			VALUES(arg_user_id, arg_course_id);
			
			UPDATE users SET accumulated_point = accumulated_point - var_point_to_unlock
			WHERE user_id = arg_user_id;
			RETURN TRUE;
		ELSE
			RETURN FALSE;
		END IF;	
	END;
$$;


ALTER FUNCTION public.fn_enroll_course(arg_user_id integer, arg_course_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_enroll_course_charges(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_enroll_course_charges(arg_user_id integer, arg_course_id integer) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE var_charges Boolean;
	BEGIN
	SELECT charges INTO var_charges FROM course WHERE course_id = arg_course_id;
-- 	Check course charges
		IF var_charges = TRUE THEN
			INSERT INTO join_course VALUES(arg_user_id, arg_course_id);
			RETURN TRUE;
		ELSE
			RETURN FALSE;
		END IF;	
	END;
$$;


ALTER FUNCTION public.fn_enroll_course_charges(arg_user_id integer, arg_course_id integer) OWNER TO examify_pxac_user;

--
-- Name: fn_increase_nums_join_exam(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_increase_nums_join_exam() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		UPDATE exam 
		SET nums_join = nums_join + 1
		WHERE exam_id = NEW.exam_id;
		
		RAISE NOTICE'Updated nums_join in exam!';
	RETURN NEW;
	END
$$;


ALTER FUNCTION public.fn_increase_nums_join_exam() OWNER TO examify_pxac_user;

--
-- Name: fn_increase_participants_course(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_increase_participants_course() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		UPDATE course 
		SET participants = participants + 1
		WHERE course_id = NEW.course_id;
		
		RAISE NOTICE'Updated participants in course!';
	RETURN NEW;
	END
$$;


ALTER FUNCTION public.fn_increase_participants_course() OWNER TO examify_pxac_user;

--
-- Name: fn_increase_total_part_exam(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_increase_total_part_exam() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		UPDATE exam SET total_part = total_part + 1 WHERE exam_id = NEW.exam_id;
		RAISE NOTICE 'Updated total_part in exam!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_increase_total_part_exam() OWNER TO examify_pxac_user;

--
-- Name: fn_increase_total_question_exam(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_increase_total_question_exam() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_exam_id INT;
	BEGIN
		SELECT part.exam_id INTO var_exam_id
		FROM set_question, part
		WHERE set_question.part_id = part.part_id
		AND set_question.set_question_id = NEW.set_question_id;
-- 		increment total_question
		UPDATE exam SET total_question = total_question + 1 WHERE exam_id = var_exam_id;
		
		RAISE NOTICE 'Updated total_question in exam!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_increase_total_question_exam() OWNER TO examify_pxac_user;

--
-- Name: fn_increase_total_question_part(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_increase_total_question_part() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_part_id INT;
	BEGIN
		SELECT set_question.part_id INTO var_part_id
		FROM set_question
		WHERE set_question.set_question_id = NEW.set_question_id;
-- 		increment total_question
		UPDATE part SET total_question = total_question + 1 WHERE part_id = var_part_id;
		
		RAISE NOTICE 'Updated total_question in part!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_increase_total_question_part() OWNER TO examify_pxac_user;

--
-- Name: fn_monday_nearly(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_monday_nearly() RETURNS timestamp without time zone
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		var_monday timestamp;
		var_distance integer;
	BEGIN
		SELECT extract(isodow from NOW()) INTO var_distance;
		var_monday:= NOW()::date - (var_distance - 1) * INTERVAL '1 day' ;
		
		RETURN var_monday;
	END;
$$;


ALTER FUNCTION public.fn_monday_nearly() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_part_delete(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_part_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT part_id
			FROM part 
			WHERE exam_id = OLD.exam_id
			AND numeric_order > OLD.numeric_order
			ORDER BY numeric_order ASC
		 LOOP
		 	UPDATE part SET numeric_order = numeric_order - 1 WHERE part_id = var_recode.part_id;
		END LOOP;
		RAISE NOTICE 'Updated numeric_order in Part!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_part_delete() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_part_update(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_part_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_new_num int;
DECLARE var_old_num int;
DECLARE var_old_part_id int;
DECLARE var_old_exam_id int;
DECLARE var_record RECORD;
	BEGIN
		var_new_num := NEW.numeric_order;
		var_old_num := OLD.numeric_order;
		var_old_part_id := OLD.part_id;
		var_old_exam_id := OLD.exam_id;
		
		IF EXISTS(SELECT * FROM part WHERE numeric_order = var_new_num AND exam_id = var_old_exam_id) THEN
-- 			Create temp Exam:
			INSERT INTO exam(exam_id, name) VALUES(-1, '');
-- 			Handle new_num > old_num:
			IF var_new_num > var_old_num THEN 
				UPDATE part SET exam_id = -1 WHERE part_id = var_old_part_id;
				
				FOR var_record IN 
					SELECT part_id 
					FROM part
					WHERE exam_id = var_old_exam_id
					AND numeric_order > var_old_num 
					AND numeric_order <= var_new_num
					ORDER BY numeric_order ASC
				LOOP
					UPDATE part SET numeric_order = numeric_order - 1 WHERE part_id = var_record.part_id;
				END LOOP;
			ELSE 
-- 				Handle new_num < old_num:
				IF var_new_num < var_old_num THEN 
					UPDATE part SET exam_id = -1 WHERE part_id = var_old_part_id;
					
					FOR var_record IN 
						SELECT part_id 
						FROM part
						WHERE exam_id = var_old_exam_id
						AND numeric_order < var_old_num 
						AND numeric_order >= var_new_num
						ORDER BY numeric_order DESC
					LOOP
						UPDATE part SET numeric_order = numeric_order + 1 WHERE part_id = var_record.part_id;
					END LOOP;
				END IF;
			END IF;
-- 			Update:
			UPDATE part SET numeric_order = var_new_num, exam_id = var_old_exam_id WHERE part_id = var_old_part_id;
-- 			Delete temp Exam:
			DELETE FROM exam WHERE exam_id = -1;
		END IF;
		RAISE NOTICE 'updated numeric order of part successfull!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_part_update() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_question_delete(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_question_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT question_id
			FROM question 
			WHERE set_question_id = OLD.set_question_id
			AND order_qn > OLD.order_qn
			ORDER BY order_qn ASC
		 LOOP
		 	UPDATE question SET order_qn = order_qn - 1 WHERE question_id = var_recode.question_id;
		END LOOP;
		RAISE NOTICE 'Updated numeric_order in Question!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_question_delete() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_question_update(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_question_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_new_num int;
DECLARE var_old_num int;
DECLARE var_old_question_id int;
DECLARE var_old_set_question_id int;
DECLARE var_record RECORD;
	BEGIN
		var_new_num := NEW.order_qn;
		var_old_num := OLD.order_qn;
		var_old_question_id := OLD.question_id;
		var_old_set_question_id := OLD.set_question_id;
		
		IF EXISTS(SELECT * FROM question WHERE order_qn = var_new_num AND set_question_id = var_old_set_question_id) THEN
-- 			Create temp set question:
			INSERT INTO set_question(set_question_id, title, numeric_order) VALUES(-1, '', 0);
-- 			Handle new_num > old_num:
			IF var_new_num > var_old_num THEN 
				UPDATE question SET set_question_id = -1 WHERE question_id = var_old_question_id;
				
				FOR var_record IN 
					SELECT question_id 
					FROM question
					WHERE set_question_id = var_old_set_question_id
					AND order_qn > var_old_num 
					AND order_qn <= var_new_num
					ORDER BY order_qn ASC
				LOOP
					UPDATE question SET order_qn = order_qn - 1 WHERE question_id = var_record.question_id;
				END LOOP;
			ELSE 
-- 				Handle new_num < old_num:
				IF var_new_num < var_old_num THEN 
					UPDATE question SET set_question_id = -1 WHERE question_id = var_old_question_id;
					
					FOR var_record IN 
						SELECT question_id 
						FROM question
						WHERE set_question_id = var_old_set_question_id
						AND order_qn < var_old_num 
						AND order_qn >= var_new_num
						ORDER BY order_qn DESC
					LOOP
						UPDATE question SET order_qn = order_qn + 1 WHERE question_id = var_record.question_id;
					END LOOP;
				END IF;
			END IF;
-- 			Update:
			UPDATE question SET order_qn = var_new_num, set_question_id = var_old_set_question_id WHERE question_id = var_old_question_id;
-- 			Delete temp set question:
			DELETE FROM set_question WHERE set_question_id = -1;
		END IF;
		RAISE NOTICE 'updated numeric order of question successfull!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_question_update() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_set_question_delete(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_set_question_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT set_question_id
			FROM set_question 
			WHERE part_id = OLD.part_id
			AND numeric_order > OLD.numeric_order
			ORDER BY numeric_order ASC
		 LOOP
		 	UPDATE set_question SET numeric_order = numeric_order - 1 WHERE set_question_id = var_recode.set_question_id;
		END LOOP;
		RAISE NOTICE 'Updated numeric_order in Set Question!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_set_question_delete() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_set_question_update(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_set_question_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_new_num int;
DECLARE var_old_num int;
DECLARE var_old_set_question_id int;
DECLARE var_old_part_id int;
DECLARE var_record RECORD;
	BEGIN
		var_new_num := NEW.numeric_order;
		var_old_num := OLD.numeric_order;
		var_old_set_question_id := OLD.set_question_id;
		var_old_part_id := OLD.part_id;
		
		IF EXISTS(SELECT * FROM set_question WHERE numeric_order = var_new_num AND part_id = var_old_part_id) THEN
-- 			Create temp Part:
			INSERT INTO part(part_id, name, numeric_order) VALUES(-1, '', 0);
-- 			Handle new_num > old_num:
			IF var_new_num > var_old_num THEN 
				UPDATE set_question SET part_id = -1 WHERE set_question_id = var_old_set_question_id;
				
				FOR var_record IN 
					SELECT set_question_id 
					FROM set_question
					WHERE part_id = var_old_part_id
					AND numeric_order > var_old_num 
					AND numeric_order <= var_new_num
					ORDER BY numeric_order ASC
				LOOP
					UPDATE set_question SET numeric_order = numeric_order - 1 WHERE set_question_id = var_record.set_question_id;
				END LOOP;
			ELSE 
-- 				Handle new_num < old_num:
				IF var_new_num < var_old_num THEN 
					UPDATE set_question SET part_id = -1 WHERE set_question_id = var_old_set_question_id;
					
					FOR var_record IN 
						SELECT set_question_id 
						FROM set_question
						WHERE part_id = var_old_part_id
						AND numeric_order < var_old_num 
						AND numeric_order >= var_new_num
						ORDER BY numeric_order DESC
					LOOP
						UPDATE set_question SET numeric_order = numeric_order + 1 WHERE set_question_id = var_record.set_question_id;
					END LOOP;
				END IF;
			END IF;
-- 			Update:
			UPDATE set_question SET numeric_order = var_new_num, part_id = var_old_part_id WHERE set_question_id = var_old_set_question_id;
-- 			Delete temp Part:
			DELETE FROM part WHERE part_id = -1;
		END IF;
		RAISE NOTICE 'updated numeric order of set question successfull!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_set_question_update() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_side_delete(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_side_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT side_id
			FROM side 
			WHERE set_question_id = OLD.set_question_id
			AND seq > OLD.seq
			ORDER BY seq ASC
		 LOOP
		 	UPDATE side SET seq = seq - 1 WHERE side_id = var_recode.side_id;
		END LOOP;
		RAISE NOTICE 'Updated numeric_order in Side!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_side_delete() OWNER TO examify_pxac_user;

--
-- Name: fn_num_order_side_update(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_num_order_side_update() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_new_num int;
DECLARE var_old_num int;
DECLARE var_old_side_id int;
DECLARE var_old_set_question_id int;
DECLARE var_record RECORD;
	BEGIN
		var_new_num := NEW.seq;
		var_old_num := OLD.seq;
		var_old_side_id := OLD.side_id;
		var_old_set_question_id := OLD.set_question_id;
		
		IF EXISTS(SELECT * FROM side WHERE seq = var_new_num AND set_question_id = var_old_set_question_id) THEN
-- 			Create temp set question:
			INSERT INTO set_question(set_question_id, title, numeric_order) VALUES(-1, '', 0);
-- 			Handle new_num > old_num:
			IF var_new_num > var_old_num THEN 
				UPDATE side SET set_question_id = -1 WHERE side_id = var_old_side_id;
				
				FOR var_record IN 
					SELECT side_id 
					FROM side
					WHERE set_question_id = var_old_set_question_id
					AND seq > var_old_num 
					AND seq <= var_new_num
					ORDER BY seq ASC
				LOOP
					UPDATE side SET seq = seq - 1 WHERE side_id = var_record.side_id;
				END LOOP;
			ELSE 
-- 				Handle new_num < old_num:
				IF var_new_num < var_old_num THEN 
					UPDATE side SET set_question_id = -1 WHERE side_id = var_old_side_id;
					
					FOR var_record IN 
						SELECT side_id 
						FROM side
						WHERE set_question_id = var_old_set_question_id
						AND seq < var_old_num 
						AND seq >= var_new_num
						ORDER BY seq DESC
					LOOP
						UPDATE side SET seq = seq + 1 WHERE side_id = var_record.side_id;
					END LOOP;
				END IF;
			END IF;
-- 			Update:
			UPDATE side SET seq = var_new_num, set_question_id = var_old_set_question_id WHERE side_id = var_old_side_id;
-- 			Delete temp set question:
			DELETE FROM set_question WHERE set_question_id = -1;
		END IF;
		RAISE NOTICE 'updated numeric order of side successfull!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_num_order_side_update() OWNER TO examify_pxac_user;

--
-- Name: fn_update_numeric_order_chapter(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_update_numeric_order_chapter() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT chapter_id
			FROM chapter
			WHERE course_id = OLD.course_id
			AND numeric_order > OLD.numeric_order
			ORDER BY numeric_order ASC
		 LOOP
		 	UPDATE chapter SET numeric_order = numeric_order - 1 WHERE chapter_id = var_recode.chapter_id;
		END LOOP;
		RAISE NOTICE 'Updated numeric_order in chapter!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_update_numeric_order_chapter() OWNER TO examify_pxac_user;

--
-- Name: fn_update_numeric_order_lesson(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_update_numeric_order_lesson() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT lesson_id
			FROM lesson
			WHERE unit_id = OLD.unit_id
			AND numeric_order > OLD.numeric_order
			ORDER BY numeric_order ASC
		 LOOP
		 	UPDATE lesson SET numeric_order = numeric_order - 1 WHERE lesson_id = var_recode.lesson_id;
		END LOOP;
		RAISE NOTICE 'Updated numeric_order in lesson!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_update_numeric_order_lesson() OWNER TO examify_pxac_user;

--
-- Name: fn_update_numeric_order_unit(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.fn_update_numeric_order_unit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE var_recode RECORD;
	BEGIN
		FOR var_recode IN 
			SELECT unit_id
			FROM unit
			WHERE chapter_id = OLD.chapter_id
			AND numeric_order > OLD.numeric_order
			ORDER BY numeric_order ASC
		 LOOP
		 	UPDATE unit SET numeric_order = numeric_order - 1 WHERE unit_id = var_recode.unit_id;
		END LOOP;
		RAISE NOTICE 'Updated numeric_order in unit!';
	RETURN NULL;
	END;
$$;


ALTER FUNCTION public.fn_update_numeric_order_unit() OWNER TO examify_pxac_user;

--
-- Name: get_status_learned_chapter(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.get_status_learned_chapter(arg_user_id integer, arg_chapter_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		status int;
	BEGIN		
		SELECT CASE WHEN total = learned THEN 2 ELSE 1 END INTO status
		FROM (
			SELECT chapter.total_lesson AS total, COUNT(*) AS learned
			FROM chapter, unit
			INNER JOIN lesson ON unit.unit_id = lesson.unit_id
			INNER JOIN join_lesson ON lesson.lesson_id = join_lesson.lesson_id
			WHERE chapter.chapter_id = arg_chapter_id
			AND unit.chapter_id = chapter.chapter_id
			AND join_lesson.student_id = arg_user_id
			GROUP BY chapter.chapter_id
		) AS TEM;

		RETURN status;
	END;
$$;


ALTER FUNCTION public.get_status_learned_chapter(arg_user_id integer, arg_chapter_id integer) OWNER TO examify_pxac_user;

--
-- Name: get_status_learned_unit(integer, integer); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.get_status_learned_unit(arg_user_id integer, arg_unit_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
	DECLARE 
		status int;
	BEGIN		
		SELECT CASE WHEN total = learned THEN 2 ELSE 1 END INTO status
		FROM (
		  SELECT unit.total_lesson AS total, COUNT(*) AS learned
		  FROM unit, lesson
		  INNER JOIN join_lesson ON lesson.lesson_id = join_lesson.lesson_id
		  WHERE unit.unit_id = arg_unit_id
		  AND unit.unit_id = lesson.unit_id
		  AND join_lesson.student_id = arg_user_id
		  GROUP BY unit.unit_id
		) AS TEM;

		RETURN status;
	END;
$$;


ALTER FUNCTION public.get_status_learned_unit(arg_user_id integer, arg_unit_id integer) OWNER TO examify_pxac_user;

--
-- Name: increase_one_participant_course(integer); Type: PROCEDURE; Schema: public; Owner: examify_pxac_user
--

CREATE PROCEDURE public.increase_one_participant_course(IN course_id_increase integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
   UPDATE course SET participants = participants + 1 WHERE course_id = course_id_increase;
END;
$$;


ALTER PROCEDURE public.increase_one_participant_course(IN course_id_increase integer) OWNER TO examify_pxac_user;

--
-- Name: increase_total_chapter(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.increase_total_chapter() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
-- 	Trigger:
	UPDATE course SET total_chapter = (total_chapter + 1) WHERE course_id = NEW.course_id;
	
	RAISE NOTICE 'Updated total chapter in course!';
	RETURN NEW;
END;

$$;


ALTER FUNCTION public.increase_total_chapter() OWNER TO examify_pxac_user;

--
-- Name: increase_total_exam(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.increase_total_exam() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
	UPDATE exam_series SET total_exam = total_exam + 1 WHERE NEW.exam_series_id = exam_series_id;

	RAISE NOTICE 'Auto increase total_exam successfully';
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.increase_total_exam() OWNER TO examify_pxac_user;

--
-- Name: increase_total_lesson(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.increase_total_lesson() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
#variable_conflict use_variable
DECLARE var_unit_id INTEGER;
DECLARE var_chapter_id INTEGER;
DECLARE var_course_id INTEGER;
BEGIN
	var_unit_id := NEW.unit_id;
	SELECT chapter_id INTO var_chapter_id FROM unit WHERE unit_id = var_unit_id;
	SELECT course_id INTO var_course_id FROM chapter WHERE chapter_id = var_chapter_id;
-- 	Trigger:
	UPDATE unit SET total_lesson = (total_lesson + 1) WHERE unit_id = var_unit_id;
	UPDATE chapter SET total_lesson = (total_lesson + 1) WHERE chapter_id = var_chapter_id;
	UPDATE course SET total_lesson = (total_lesson + 1) WHERE course_id = var_course_id;
	
	RAISE NOTICE 'Updated total lesson in unit, chapter and course!';
	RETURN NEW;
END;

$$;


ALTER FUNCTION public.increase_total_lesson() OWNER TO examify_pxac_user;

--
-- Name: increase_total_video_course(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.increase_total_video_course() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
#variable_conflict use_variable
DECLARE var_type SMALLINT;
DECLARE var_video_time INTEGER;
DECLARE var_course_id INTEGER;
BEGIN
	var_type:= NEW.type;
	var_video_time:= NEW.video_time;
	--check
	IF var_type = 1 AND var_video_time != 0 THEN
		SELECT chapter.course_id INTO var_course_id
		FROM chapter, unit
		WHERE unit.unit_id = NEW.unit_id
		AND unit.chapter_id = chapter.chapter_id;
	--Trigger	
		UPDATE course 
		SET total_video_time = total_video_time + var_video_time
		WHERE  course_id = var_course_id;
	--Notice	
		RAISE NOTICE 'Updated total video time in course!';
	END IF;
	RETURN NULL;
END
$$;


ALTER FUNCTION public.increase_total_video_course() OWNER TO examify_pxac_user;

--
-- Name: proc_like_comment(integer, integer); Type: PROCEDURE; Schema: public; Owner: examify_pxac_user
--

CREATE PROCEDURE public.proc_like_comment(IN arg_user_id integer, IN arg_comment_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
   INSERT INTO likes (user_id, comment_id) VALUES (arg_user_id, arg_comment_id);
   UPDATE comment SET total_like = total_like + 1 WHERE comment.comment_id = arg_comment_id;
END;
$$;


ALTER PROCEDURE public.proc_like_comment(IN arg_user_id integer, IN arg_comment_id integer) OWNER TO examify_pxac_user;

--
-- Name: proc_unlike_comment(integer, integer); Type: PROCEDURE; Schema: public; Owner: examify_pxac_user
--

CREATE PROCEDURE public.proc_unlike_comment(IN arg_user_id integer, IN arg_comment_id integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
   DELETE FROM likes WHERE user_id = arg_user_id AND comment_id = arg_comment_id;
   UPDATE comment SET total_like = total_like - 1 WHERE comment.comment_id = arg_comment_id;
END;
$$;


ALTER PROCEDURE public.proc_unlike_comment(IN arg_user_id integer, IN arg_comment_id integer) OWNER TO examify_pxac_user;

--
-- Name: update_reviews_stat(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.update_reviews_stat() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    p_id           INTEGER;
    avg_rating_var FLOAT;
BEGIN
    IF TG_OP = 'INSERT' THEN
        SELECT NEW.product_id INTO p_id;

        UPDATE api_product
        SET reviews_count = reviews_count + 1
        WHERE id = p_id;
    ELSIF TG_OP = 'DELETE' THEN
        SELECT OLD.product_id INTO p_id;

        UPDATE api_product
        SET reviews_count = reviews_count - 1
        WHERE id = p_id;
    END IF;

    SELECT AVG(rating) INTO avg_rating_var FROM api_review WHERE product_id = p_id;
    RAISE NOTICE 'Update rating for product with avg_rating = %, p_id = %', avg_rating_var, p_id;
    UPDATE api_product
    SET avg_rating = avg_rating_var
    WHERE id = p_id;

    RETURN NULL;
END;
$$;


ALTER FUNCTION public.update_reviews_stat() OWNER TO examify_pxac_user;

--
-- Name: update_sets_count(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.update_sets_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE update_count INT; type_id INT;
	BEGIN
		IF TG_OP = 'INSERT' THEN	
			type_id = NEW.fc_type_id;
		ELSE
			type_id = OLD.fc_type_id;
		END IF;

		update_count = (SELECT COUNT(*) FROM flashcard_set fs WHERE fs.fc_type_id = type_id);
		UPDATE flashcard_type ft SET sets_count = update_count WHERE ft.fc_type_id = type_id;
		RAISE NOTICE 'Update sets count of type: %', type_id;

		RETURN NULL;
	END;
$$;


ALTER FUNCTION public.update_sets_count() OWNER TO examify_pxac_user;

--
-- Name: update_timestamp(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   NEW.updated_at = now(); 
   RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_timestamp() OWNER TO examify_pxac_user;

--
-- Name: update_total_lesson(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.update_total_lesson() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
#variable_conflict use_variable
DECLARE var_old_unit_id INTEGER;
DECLARE var_old_chapter_id INTEGER;
DECLARE var_old_course_id INTEGER;
DECLARE var_new_unit_id INTEGER;
DECLARE var_new_chapter_id INTEGER;
DECLARE var_new_course_id INTEGER;
BEGIN
	-- asign variable
	var_new_unit_id :=  NEW.unit_id; 
	SELECT chapter_id INTO var_new_chapter_id FROM unit WHERE unit_id = var_new_unit_id;
	SELECT course_id INTO var_new_course_id FROM chapter WHERE chapter_id = var_new_chapter_id ;
	var_old_unit_id :=  OLD.unit_id; 
	SELECT chapter_id INTO var_old_chapter_id FROM unit WHERE unit_id = var_old_unit_id;
	SELECT course_id INTO var_old_course_id FROM chapter WHERE chapter_id = var_old_chapter_id;
	-- trigger
	IF var_new_unit_id != var_old_unit_id THEN
		UPDATE unit SET total_lesson = (total_lesson + 1) WHERE unit_id = var_new_unit_id;
		UPDATE unit SET total_lesson = (total_lesson - 1) WHERE unit_id = var_old_unit_id;

		IF var_new_chapter_id != var_old_chapter_id THEN
			UPDATE chapter SET total_lesson = (total_lesson + 1) WHERE chapter_id = var_new_chapter_id;
			UPDATE chapter SET total_lesson = (total_lesson - 1) WHERE chapter_id = var_old_chapter_id;

			IF var_new_course_id != var_old_course_id THEN
				UPDATE course SET total_lesson = (total_lesson + 1) WHERE course_id = var_new_course_id;
				UPDATE course SET total_lesson = (total_lesson - 1) WHERE course_id = var_old_course_id;
			END IF;
		END IF;
	END IF;
	
	RAISE NOTICE 'Updated total lesson in unit, chapter and course!';
	RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_total_lesson() OWNER TO examify_pxac_user;

--
-- Name: update_total_video_course(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.update_total_video_course() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
#variable_conflict use_variable
DECLARE var_video_time_old INTEGER;
DECLARE var_video_time_new INTEGER;
DECLARE var_course_id INTEGER;
BEGIN
	var_video_time_new:= NEW.video_time;
	var_video_time_old:= OLD.video_time;
	SELECT chapter.course_id INTO var_course_id
		FROM chapter, unit
		WHERE unit.unit_id = OLD.unit_id
		AND unit.chapter_id = chapter.chapter_id;
	--Trigger	
		UPDATE course 
		SET total_video_time = total_video_time - var_video_time_old + var_video_time_new
		WHERE  course_id = var_course_id;
	--Notice	
	RAISE NOTICE 'Updated total video time in course!';
		
	RETURN NEW;
END
$$;


ALTER FUNCTION public.update_total_video_course() OWNER TO examify_pxac_user;

--
-- Name: update_variations_count(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.update_variations_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    p_id                 INTEGER;
    variations_count_var INTEGER;
BEGIN
    IF TG_OP = 'INSERT' THEN
        SELECT NEW.product_id INTO p_id;
    ELSIF TG_OP = 'DELETE' THEN
        SELECT OLD.product_id INTO p_id;
    END IF;

    SELECT COUNT(*) INTO variations_count_var FROM api_variation WHERE product_id = p_id AND is_deleted = false;
    UPDATE api_product
    SET variations_count = variations_count_var
    WHERE id = p_id;
    RAISE NOTICE 'Update variations count for product with id = %', p_id;

    RETURN NULL;
END;
$$;


ALTER FUNCTION public.update_variations_count() OWNER TO examify_pxac_user;

--
-- Name: update_words_count(); Type: FUNCTION; Schema: public; Owner: examify_pxac_user
--

CREATE FUNCTION public.update_words_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	DECLARE update_count INT; set_id INT;
	BEGIN
		IF TG_OP = 'INSERT' THEN	
			set_id = NEW.fc_set_id;
		ELSE
			set_id = OLD.fc_set_id;
		END IF;

		update_count = (SELECT COUNT(*) FROM flashcard f WHERE f.fc_set_id = set_id);
		UPDATE flashcard_set fs SET words_count = update_count WHERE fs.fc_set_id = set_id;
		RAISE NOTICE 'Value: %', set_id;

		RETURN NULL;
	END;
$$;


ALTER FUNCTION public.update_words_count() OWNER TO examify_pxac_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: answer_record; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.answer_record (
    exam_taking_id integer NOT NULL,
    question_id integer NOT NULL,
    choice_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.answer_record OWNER TO examify_pxac_user;

--
-- Name: api_address; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_address (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL,
    phone character varying(15) NOT NULL,
    full_name character varying(300) NOT NULL,
    province character varying(100) NOT NULL,
    province_code integer NOT NULL,
    district character varying(100) NOT NULL,
    district_code integer NOT NULL,
    ward character varying(100) NOT NULL,
    ward_code integer NOT NULL,
    street character varying(300) NOT NULL,
    created_by_id bigint NOT NULL
);


ALTER TABLE public.api_address OWNER TO examify_pxac_user;

--
-- Name: api_address_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_address ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_cartitem; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_cartitem (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    qty integer NOT NULL,
    created_by_id bigint NOT NULL,
    product_id bigint NOT NULL,
    variation_id bigint NOT NULL
);


ALTER TABLE public.api_cartitem OWNER TO examify_pxac_user;

--
-- Name: api_cartitem_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_cartitem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_cartitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_category; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_category (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(300) NOT NULL,
    "desc" text,
    img_url text NOT NULL,
    is_deleted boolean NOT NULL
);


ALTER TABLE public.api_category OWNER TO examify_pxac_user;

--
-- Name: api_category_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_category ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_favoriteitem; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_favoriteitem (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id bigint NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.api_favoriteitem OWNER TO examify_pxac_user;

--
-- Name: api_favoriteitem_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_favoriteitem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_favoriteitem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_order; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_order (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    phone character varying(15) NOT NULL,
    full_name character varying(300) NOT NULL,
    province character varying(100) NOT NULL,
    province_code integer NOT NULL,
    district character varying(100) NOT NULL,
    district_code integer NOT NULL,
    ward character varying(100) NOT NULL,
    ward_code integer NOT NULL,
    street character varying(300) NOT NULL,
    status character varying(20) NOT NULL,
    total numeric(20,2) NOT NULL,
    payment text NOT NULL,
    created_by_id bigint NOT NULL,
    email character varying(254) NOT NULL,
    shipping_date timestamp with time zone,
    voucher_id bigint
);


ALTER TABLE public.api_order OWNER TO examify_pxac_user;

--
-- Name: api_order_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_orderdetail; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_orderdetail (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    price numeric(20,2) NOT NULL,
    qty integer NOT NULL,
    order_id bigint NOT NULL,
    variation_id bigint NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.api_orderdetail OWNER TO examify_pxac_user;

--
-- Name: api_orderdetail_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_orderdetail ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_orderdetail_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_payment; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_payment (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(300) NOT NULL,
    exp date,
    provider_id bigint NOT NULL,
    created_by_id bigint NOT NULL,
    number character varying(30),
    cvc character varying(4)
);


ALTER TABLE public.api_payment OWNER TO examify_pxac_user;

--
-- Name: api_payment_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_payment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_payment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_paymentprovider; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_paymentprovider (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    img_url text NOT NULL,
    name text NOT NULL,
    method character varying(50) NOT NULL
);


ALTER TABLE public.api_paymentprovider OWNER TO examify_pxac_user;

--
-- Name: api_paymentprovider_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_paymentprovider ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_paymentprovider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_product; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_product (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(300) NOT NULL,
    "desc" text,
    price numeric(20,2) NOT NULL,
    thumbnail text NOT NULL,
    category_id bigint NOT NULL,
    reviews_count integer NOT NULL,
    is_deleted boolean NOT NULL,
    avg_rating numeric(20,1),
    variations_count integer NOT NULL,
    discount integer NOT NULL,
    material text,
    length numeric(20,2),
    height numeric(20,2),
    more_info text,
    weight numeric(20,2),
    width numeric(20,2)
);


ALTER TABLE public.api_product OWNER TO examify_pxac_user;

--
-- Name: api_product_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_product ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_review; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_review (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    content text NOT NULL,
    rating integer NOT NULL,
    created_by_id bigint NOT NULL,
    variation_id bigint NOT NULL,
    product_id bigint NOT NULL,
    img_urls text[] NOT NULL
);


ALTER TABLE public.api_review OWNER TO examify_pxac_user;

--
-- Name: api_review_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_review ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_usedvoucher; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_usedvoucher (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_id bigint NOT NULL,
    voucher_id bigint NOT NULL
);


ALTER TABLE public.api_usedvoucher OWNER TO examify_pxac_user;

--
-- Name: api_usedvoucher_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_usedvoucher ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_usedvoucher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_variation; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_variation (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    inventory integer NOT NULL,
    name character varying(300) NOT NULL,
    img_urls text[] NOT NULL,
    product_id bigint NOT NULL,
    is_deleted boolean NOT NULL
);


ALTER TABLE public.api_variation OWNER TO examify_pxac_user;

--
-- Name: api_variation_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_variation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_variation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_voucher; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.api_voucher (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_deleted boolean NOT NULL,
    discount integer NOT NULL,
    from_date date NOT NULL,
    to_date date NOT NULL,
    code character varying(30) NOT NULL,
    inventory integer NOT NULL
);


ALTER TABLE public.api_voucher OWNER TO examify_pxac_user;

--
-- Name: api_voucher_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.api_voucher ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_voucher_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO examify_pxac_user;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO examify_pxac_user;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO examify_pxac_user;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: authentication_user; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.authentication_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    email_verified boolean NOT NULL,
    dob date,
    full_name text,
    gender character varying(15),
    phone character varying(15),
    avatar text NOT NULL
);


ALTER TABLE public.authentication_user OWNER TO examify_pxac_user;

--
-- Name: authentication_user_groups; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.authentication_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.authentication_user_groups OWNER TO examify_pxac_user;

--
-- Name: authentication_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.authentication_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.authentication_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: authentication_user_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.authentication_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.authentication_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: authentication_user_user_permissions; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.authentication_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.authentication_user_user_permissions OWNER TO examify_pxac_user;

--
-- Name: authentication_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.authentication_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.authentication_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: chapter; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.chapter (
    chapter_id integer NOT NULL,
    course_id integer NOT NULL,
    numeric_order integer NOT NULL,
    name character varying(150) NOT NULL,
    total_lesson smallint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.chapter OWNER TO examify_pxac_user;

--
-- Name: chapter_chapter_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.chapter_chapter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chapter_chapter_id_seq OWNER TO examify_pxac_user;

--
-- Name: chapter_chapter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.chapter_chapter_id_seq OWNED BY public.chapter.chapter_id;


--
-- Name: choice; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.choice (
    choice_id integer NOT NULL,
    question_id integer,
    order_choice integer NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    key boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.choice OWNER TO examify_pxac_user;

--
-- Name: choice_choice_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.choice_choice_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.choice_choice_id_seq OWNER TO examify_pxac_user;

--
-- Name: choice_choice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.choice_choice_id_seq OWNED BY public.choice.choice_id;


--
-- Name: comment; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.comment (
    comment_id integer NOT NULL,
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    content text,
    total_like integer DEFAULT 0,
    respond_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.comment OWNER TO examify_pxac_user;

--
-- Name: comment_comment_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.comment_comment_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comment_comment_id_seq OWNER TO examify_pxac_user;

--
-- Name: comment_comment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.comment_comment_id_seq OWNED BY public.comment.comment_id;


--
-- Name: course; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.course (
    course_id integer NOT NULL,
    name character varying(150) NOT NULL,
    image text NOT NULL,
    level character varying(10) NOT NULL,
    charges boolean NOT NULL,
    point_to_unlock integer,
    point_reward integer NOT NULL,
    quantity_rating integer DEFAULT 0 NOT NULL,
    avg_rating numeric(3,2) DEFAULT 0 NOT NULL,
    participants integer DEFAULT 0 NOT NULL,
    price integer,
    discount integer,
    total_chapter integer DEFAULT 0 NOT NULL,
    total_lesson integer DEFAULT 0 NOT NULL,
    total_video_time integer DEFAULT 0 NOT NULL,
    achieves text,
    description text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.course OWNER TO examify_pxac_user;

--
-- Name: course_course_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.course_course_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_course_id_seq OWNER TO examify_pxac_user;

--
-- Name: course_course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.course_course_id_seq OWNED BY public.course.course_id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO examify_pxac_user;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO examify_pxac_user;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO examify_pxac_user;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO examify_pxac_user;

--
-- Name: exam; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.exam (
    exam_id integer NOT NULL,
    exam_series_id integer,
    name character varying(255) NOT NULL,
    total_part integer DEFAULT 0,
    total_question integer DEFAULT 0,
    total_comment integer DEFAULT 0,
    point_reward integer DEFAULT 0,
    nums_join integer DEFAULT 0,
    hashtag text[] DEFAULT ARRAY['Listening'::text, 'Reading'::text],
    is_full_explanation boolean DEFAULT false,
    audio text,
    duration integer DEFAULT 0,
    file_download text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.exam OWNER TO examify_pxac_user;

--
-- Name: exam_exam_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.exam_exam_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_exam_id_seq OWNER TO examify_pxac_user;

--
-- Name: exam_exam_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.exam_exam_id_seq OWNED BY public.exam.exam_id;


--
-- Name: exam_series; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.exam_series (
    exam_series_id integer NOT NULL,
    name text NOT NULL,
    total_exam integer DEFAULT 0 NOT NULL,
    public_date date,
    author text DEFAULT ''::text,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.exam_series OWNER TO examify_pxac_user;

--
-- Name: exam_series_exam_series_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.exam_series_exam_series_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_series_exam_series_id_seq OWNER TO examify_pxac_user;

--
-- Name: exam_series_exam_series_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.exam_series_exam_series_id_seq OWNED BY public.exam_series.exam_series_id;


--
-- Name: exam_taking; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.exam_taking (
    exam_taking_id integer NOT NULL,
    exam_id integer NOT NULL,
    user_id integer NOT NULL,
    time_finished integer DEFAULT 0 NOT NULL,
    nums_of_correct_qn integer DEFAULT 0 NOT NULL,
    total_question integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.exam_taking OWNER TO examify_pxac_user;

--
-- Name: exam_taking_exam_taking_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.exam_taking_exam_taking_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exam_taking_exam_taking_id_seq OWNER TO examify_pxac_user;

--
-- Name: exam_taking_exam_taking_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.exam_taking_exam_taking_id_seq OWNED BY public.exam_taking.exam_taking_id;


--
-- Name: flashcard; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.flashcard (
    fc_id integer NOT NULL,
    fc_set_id integer,
    word text NOT NULL,
    meaning text NOT NULL,
    type_of_word character varying(15) NOT NULL,
    pronounce text,
    audio text,
    example text,
    note text,
    image text,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.flashcard OWNER TO examify_pxac_user;

--
-- Name: flashcard_fc_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.flashcard_fc_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.flashcard_fc_id_seq OWNER TO examify_pxac_user;

--
-- Name: flashcard_fc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.flashcard_fc_id_seq OWNED BY public.flashcard.fc_id;


--
-- Name: flashcard_set; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.flashcard_set (
    fc_set_id integer NOT NULL,
    fc_type_id integer,
    name text NOT NULL,
    description text,
    words_count integer DEFAULT 0,
    system_belong boolean DEFAULT false,
    access character varying(16),
    views integer DEFAULT 0,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.flashcard_set OWNER TO examify_pxac_user;

--
-- Name: flashcard_set_fc_set_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.flashcard_set_fc_set_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.flashcard_set_fc_set_id_seq OWNER TO examify_pxac_user;

--
-- Name: flashcard_set_fc_set_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.flashcard_set_fc_set_id_seq OWNED BY public.flashcard_set.fc_set_id;


--
-- Name: flashcard_share_permit; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.flashcard_share_permit (
    user_id integer NOT NULL,
    fc_set_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.flashcard_share_permit OWNER TO examify_pxac_user;

--
-- Name: flashcard_type; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.flashcard_type (
    fc_type_id integer NOT NULL,
    type character varying(50) NOT NULL,
    description text,
    sets_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.flashcard_type OWNER TO examify_pxac_user;

--
-- Name: flashcard_type_fc_type_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.flashcard_type_fc_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.flashcard_type_fc_type_id_seq OWNER TO examify_pxac_user;

--
-- Name: flashcard_type_fc_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.flashcard_type_fc_type_id_seq OWNED BY public.flashcard_type.fc_type_id;


--
-- Name: hashtag; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.hashtag (
    hashtag_id integer NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.hashtag OWNER TO examify_pxac_user;

--
-- Name: hashtag_hashtag_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.hashtag_hashtag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.hashtag_hashtag_id_seq OWNER TO examify_pxac_user;

--
-- Name: hashtag_hashtag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.hashtag_hashtag_id_seq OWNED BY public.hashtag.hashtag_id;


--
-- Name: join_course; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.join_course (
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.join_course OWNER TO examify_pxac_user;

--
-- Name: join_lesson; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.join_lesson (
    student_id integer NOT NULL,
    lesson_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.join_lesson OWNER TO examify_pxac_user;

--
-- Name: learnt_list; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.learnt_list (
    fc_id integer NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.learnt_list OWNER TO examify_pxac_user;

--
-- Name: lesson; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.lesson (
    lesson_id integer NOT NULL,
    unit_id integer NOT NULL,
    numeric_order integer NOT NULL,
    name text NOT NULL,
    type smallint NOT NULL,
    video_url text,
    video_time integer DEFAULT 0 NOT NULL,
    flashcard_set_id integer,
    text text,
    description text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.lesson OWNER TO examify_pxac_user;

--
-- Name: lesson_lesson_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.lesson_lesson_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_lesson_id_seq OWNER TO examify_pxac_user;

--
-- Name: lesson_lesson_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.lesson_lesson_id_seq OWNED BY public.lesson.lesson_id;


--
-- Name: like; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public."like" (
    user_id integer NOT NULL,
    comment_id integer NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public."like" OWNER TO examify_pxac_user;

--
-- Name: likes; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.likes (
    user_id integer NOT NULL,
    comment_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.likes OWNER TO examify_pxac_user;

--
-- Name: note; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.note (
    note_id integer NOT NULL,
    student_id integer NOT NULL,
    lesson_id integer NOT NULL,
    note text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.note OWNER TO examify_pxac_user;

--
-- Name: note_note_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.note_note_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.note_note_id_seq OWNER TO examify_pxac_user;

--
-- Name: note_note_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.note_note_id_seq OWNED BY public.note.note_id;


--
-- Name: part; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.part (
    part_id integer NOT NULL,
    exam_id integer,
    name character varying(255) NOT NULL,
    total_question integer DEFAULT 0,
    number_of_explanation integer DEFAULT 0,
    numeric_order integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.part OWNER TO examify_pxac_user;

--
-- Name: part_option; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.part_option (
    exam_taking_id integer NOT NULL,
    part_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.part_option OWNER TO examify_pxac_user;

--
-- Name: part_part_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.part_part_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.part_part_id_seq OWNER TO examify_pxac_user;

--
-- Name: part_part_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.part_part_id_seq OWNED BY public.part.part_id;


--
-- Name: question; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.question (
    question_id integer NOT NULL,
    set_question_id integer,
    hashtag_id integer,
    name character varying(255) DEFAULT ''::character varying,
    explain text DEFAULT ''::text,
    order_qn integer NOT NULL,
    level integer DEFAULT 1 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.question OWNER TO examify_pxac_user;

--
-- Name: question_question_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.question_question_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.question_question_id_seq OWNER TO examify_pxac_user;

--
-- Name: question_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.question_question_id_seq OWNED BY public.question.question_id;


--
-- Name: rank; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.rank (
    rank_id integer NOT NULL,
    rank_name text NOT NULL,
    point_to_unlock integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rank OWNER TO examify_pxac_user;

--
-- Name: rank_rank_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.rank_rank_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rank_rank_id_seq OWNER TO examify_pxac_user;

--
-- Name: rank_rank_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.rank_rank_id_seq OWNED BY public.rank.rank_id;


--
-- Name: rating; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.rating (
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    rate integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rating OWNER TO examify_pxac_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.roles (
    role_id integer NOT NULL,
    role_name character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO examify_pxac_user;

--
-- Name: roles_role_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.roles_role_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_role_id_seq OWNER TO examify_pxac_user;

--
-- Name: roles_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.roles_role_id_seq OWNED BY public.roles.role_id;


--
-- Name: set_question; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.set_question (
    set_question_id integer NOT NULL,
    part_id integer,
    title character varying(255) DEFAULT ''::character varying,
    numeric_order integer NOT NULL,
    audio text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.set_question OWNER TO examify_pxac_user;

--
-- Name: set_question_set_question_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.set_question_set_question_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.set_question_set_question_id_seq OWNER TO examify_pxac_user;

--
-- Name: set_question_set_question_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.set_question_set_question_id_seq OWNED BY public.set_question.set_question_id;


--
-- Name: side; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.side (
    side_id integer NOT NULL,
    set_question_id integer,
    paragraph text NOT NULL,
    seq integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.side OWNER TO examify_pxac_user;

--
-- Name: side_side_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.side_side_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.side_side_id_seq OWNER TO examify_pxac_user;

--
-- Name: side_side_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.side_side_id_seq OWNED BY public.side.side_id;


--
-- Name: slide; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.slide (
    slide_id integer NOT NULL,
    sequence integer NOT NULL,
    lesson_id integer,
    text text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.slide OWNER TO examify_pxac_user;

--
-- Name: slide_slide_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.slide_slide_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.slide_slide_id_seq OWNER TO examify_pxac_user;

--
-- Name: slide_slide_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.slide_slide_id_seq OWNED BY public.slide.slide_id;


--
-- Name: unit; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.unit (
    unit_id integer NOT NULL,
    chapter_id integer NOT NULL,
    numeric_order integer NOT NULL,
    name character varying(150) NOT NULL,
    total_lesson smallint DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.unit OWNER TO examify_pxac_user;

--
-- Name: unit_unit_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.unit_unit_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.unit_unit_id_seq OWNER TO examify_pxac_user;

--
-- Name: unit_unit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.unit_unit_id_seq OWNED BY public.unit.unit_id;


--
-- Name: user_to_role; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.user_to_role (
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_to_role OWNER TO examify_pxac_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: examify_pxac_user
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    mail text NOT NULL,
    password text NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    date_of_birth date,
    phone_number character varying(10),
    avt text DEFAULT 'https://media.istockphoto.com/id/1223671392/vector/default-profile-picture-avatar-photo-placeholder-vector-illustration.jpg?s=170667a&w=0&k=20&c=m-F9Doa2ecNYEEjeplkFCmZBlc5tm1pl1F7cBCh9ZzM='::text,
    banner text DEFAULT 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAX8AAACECAMAAABPuNs7AAAACVBMVEWAgICLi4uUlJSuV9pqAAABI0lEQVR4nO3QMQEAAAjAILV/aGPwjAjMbZybnTjbP9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b/Vv9W/1b+1cxvnHi9hBAfkOyqGAAAAAElFTkSuQmCC'::text,
    description text,
    rank_id integer DEFAULT 1,
    accumulated_point integer DEFAULT 0,
    rank_point integer DEFAULT 0,
    refresh_token text DEFAULT ''::text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO examify_pxac_user;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: examify_pxac_user
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO examify_pxac_user;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: examify_pxac_user
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: chapter chapter_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.chapter ALTER COLUMN chapter_id SET DEFAULT nextval('public.chapter_chapter_id_seq'::regclass);


--
-- Name: choice choice_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.choice ALTER COLUMN choice_id SET DEFAULT nextval('public.choice_choice_id_seq'::regclass);


--
-- Name: comment comment_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.comment ALTER COLUMN comment_id SET DEFAULT nextval('public.comment_comment_id_seq'::regclass);


--
-- Name: course course_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.course ALTER COLUMN course_id SET DEFAULT nextval('public.course_course_id_seq'::regclass);


--
-- Name: exam exam_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam ALTER COLUMN exam_id SET DEFAULT nextval('public.exam_exam_id_seq'::regclass);


--
-- Name: exam_series exam_series_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam_series ALTER COLUMN exam_series_id SET DEFAULT nextval('public.exam_series_exam_series_id_seq'::regclass);


--
-- Name: exam_taking exam_taking_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam_taking ALTER COLUMN exam_taking_id SET DEFAULT nextval('public.exam_taking_exam_taking_id_seq'::regclass);


--
-- Name: flashcard fc_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard ALTER COLUMN fc_id SET DEFAULT nextval('public.flashcard_fc_id_seq'::regclass);


--
-- Name: flashcard_set fc_set_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_set ALTER COLUMN fc_set_id SET DEFAULT nextval('public.flashcard_set_fc_set_id_seq'::regclass);


--
-- Name: flashcard_type fc_type_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_type ALTER COLUMN fc_type_id SET DEFAULT nextval('public.flashcard_type_fc_type_id_seq'::regclass);


--
-- Name: hashtag hashtag_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.hashtag ALTER COLUMN hashtag_id SET DEFAULT nextval('public.hashtag_hashtag_id_seq'::regclass);


--
-- Name: lesson lesson_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.lesson ALTER COLUMN lesson_id SET DEFAULT nextval('public.lesson_lesson_id_seq'::regclass);


--
-- Name: note note_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.note ALTER COLUMN note_id SET DEFAULT nextval('public.note_note_id_seq'::regclass);


--
-- Name: part part_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.part ALTER COLUMN part_id SET DEFAULT nextval('public.part_part_id_seq'::regclass);


--
-- Name: question question_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.question ALTER COLUMN question_id SET DEFAULT nextval('public.question_question_id_seq'::regclass);


--
-- Name: rank rank_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.rank ALTER COLUMN rank_id SET DEFAULT nextval('public.rank_rank_id_seq'::regclass);


--
-- Name: roles role_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN role_id SET DEFAULT nextval('public.roles_role_id_seq'::regclass);


--
-- Name: set_question set_question_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.set_question ALTER COLUMN set_question_id SET DEFAULT nextval('public.set_question_set_question_id_seq'::regclass);


--
-- Name: side side_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.side ALTER COLUMN side_id SET DEFAULT nextval('public.side_side_id_seq'::regclass);


--
-- Name: slide slide_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.slide ALTER COLUMN slide_id SET DEFAULT nextval('public.slide_slide_id_seq'::regclass);


--
-- Name: unit unit_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.unit ALTER COLUMN unit_id SET DEFAULT nextval('public.unit_unit_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: answer_record; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.answer_record (exam_taking_id, question_id, choice_id, created_at, updated_at) FROM stdin;
\.
COPY public.answer_record (exam_taking_id, question_id, choice_id, created_at, updated_at) FROM '$$PATH$$/3942.dat';

--
-- Data for Name: api_address; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_address (id, created_at, updated_at, email, phone, full_name, province, province_code, district, district_code, ward, ward_code, street, created_by_id) FROM stdin;
\.
COPY public.api_address (id, created_at, updated_at, email, phone, full_name, province, province_code, district, district_code, ward, ward_code, street, created_by_id) FROM '$$PATH$$/3975.dat';

--
-- Data for Name: api_cartitem; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_cartitem (id, created_at, updated_at, qty, created_by_id, product_id, variation_id) FROM stdin;
\.
COPY public.api_cartitem (id, created_at, updated_at, qty, created_by_id, product_id, variation_id) FROM '$$PATH$$/3981.dat';

--
-- Data for Name: api_category; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_category (id, created_at, updated_at, name, "desc", img_url, is_deleted) FROM stdin;
\.
COPY public.api_category (id, created_at, updated_at, name, "desc", img_url, is_deleted) FROM '$$PATH$$/3963.dat';

--
-- Data for Name: api_favoriteitem; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_favoriteitem (id, created_at, updated_at, created_by_id, product_id) FROM stdin;
\.
COPY public.api_favoriteitem (id, created_at, updated_at, created_by_id, product_id) FROM '$$PATH$$/3983.dat';

--
-- Data for Name: api_order; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_order (id, created_at, updated_at, phone, full_name, province, province_code, district, district_code, ward, ward_code, street, status, total, payment, created_by_id, email, shipping_date, voucher_id) FROM stdin;
\.
COPY public.api_order (id, created_at, updated_at, phone, full_name, province, province_code, district, district_code, ward, ward_code, street, status, total, payment, created_by_id, email, shipping_date, voucher_id) FROM '$$PATH$$/3967.dat';

--
-- Data for Name: api_orderdetail; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_orderdetail (id, created_at, updated_at, price, qty, order_id, variation_id, product_id) FROM stdin;
\.
COPY public.api_orderdetail (id, created_at, updated_at, price, qty, order_id, variation_id, product_id) FROM '$$PATH$$/3971.dat';

--
-- Data for Name: api_payment; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_payment (id, created_at, updated_at, name, exp, provider_id, created_by_id, number, cvc) FROM stdin;
\.
COPY public.api_payment (id, created_at, updated_at, name, exp, provider_id, created_by_id, number, cvc) FROM '$$PATH$$/3979.dat';

--
-- Data for Name: api_paymentprovider; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_paymentprovider (id, created_at, updated_at, is_deleted, img_url, name, method) FROM stdin;
\.
COPY public.api_paymentprovider (id, created_at, updated_at, is_deleted, img_url, name, method) FROM '$$PATH$$/3977.dat';

--
-- Data for Name: api_product; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_product (id, created_at, updated_at, name, "desc", price, thumbnail, category_id, reviews_count, is_deleted, avg_rating, variations_count, discount, material, length, height, more_info, weight, width) FROM stdin;
\.
COPY public.api_product (id, created_at, updated_at, name, "desc", price, thumbnail, category_id, reviews_count, is_deleted, avg_rating, variations_count, discount, material, length, height, more_info, weight, width) FROM '$$PATH$$/3965.dat';

--
-- Data for Name: api_review; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_review (id, created_at, updated_at, content, rating, created_by_id, variation_id, product_id, img_urls) FROM stdin;
\.
COPY public.api_review (id, created_at, updated_at, content, rating, created_by_id, variation_id, product_id, img_urls) FROM '$$PATH$$/3973.dat';

--
-- Data for Name: api_usedvoucher; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_usedvoucher (id, created_at, updated_at, user_id, voucher_id) FROM stdin;
\.
COPY public.api_usedvoucher (id, created_at, updated_at, user_id, voucher_id) FROM '$$PATH$$/3987.dat';

--
-- Data for Name: api_variation; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_variation (id, created_at, updated_at, inventory, name, img_urls, product_id, is_deleted) FROM stdin;
\.
COPY public.api_variation (id, created_at, updated_at, inventory, name, img_urls, product_id, is_deleted) FROM '$$PATH$$/3969.dat';

--
-- Data for Name: api_voucher; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.api_voucher (id, created_at, updated_at, is_deleted, discount, from_date, to_date, code, inventory) FROM stdin;
\.
COPY public.api_voucher (id, created_at, updated_at, is_deleted, discount, from_date, to_date, code, inventory) FROM '$$PATH$$/3985.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3951.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3953.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3949.dat';

--
-- Data for Name: authentication_user; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.authentication_user (id, password, last_login, is_superuser, created_at, updated_at, email, is_staff, is_active, date_joined, email_verified, dob, full_name, gender, phone, avatar) FROM stdin;
\.
COPY public.authentication_user (id, password, last_login, is_superuser, created_at, updated_at, email, is_staff, is_active, date_joined, email_verified, dob, full_name, gender, phone, avatar) FROM '$$PATH$$/3955.dat';

--
-- Data for Name: authentication_user_groups; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.authentication_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.authentication_user_groups (id, user_id, group_id) FROM '$$PATH$$/3957.dat';

--
-- Data for Name: authentication_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.authentication_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.authentication_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3959.dat';

--
-- Data for Name: chapter; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.chapter (chapter_id, course_id, numeric_order, name, total_lesson, created_at, updated_at) FROM stdin;
\.
COPY public.chapter (chapter_id, course_id, numeric_order, name, total_lesson, created_at, updated_at) FROM '$$PATH$$/3897.dat';

--
-- Data for Name: choice; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.choice (choice_id, question_id, order_choice, name, key, created_at, updated_at) FROM stdin;
\.
COPY public.choice (choice_id, question_id, order_choice, name, key, created_at, updated_at) FROM '$$PATH$$/3937.dat';

--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.comment (comment_id, student_id, course_id, content, total_like, respond_id, created_at, updated_at) FROM stdin;
\.
COPY public.comment (comment_id, student_id, course_id, content, total_like, respond_id, created_at, updated_at) FROM '$$PATH$$/3908.dat';

--
-- Data for Name: course; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.course (course_id, name, image, level, charges, point_to_unlock, point_reward, quantity_rating, avg_rating, participants, price, discount, total_chapter, total_lesson, total_video_time, achieves, description, created_by, created_at, updated_at) FROM stdin;
\.
COPY public.course (course_id, name, image, level, charges, point_to_unlock, point_reward, quantity_rating, avg_rating, participants, price, discount, total_chapter, total_lesson, total_video_time, achieves, description, created_by, created_at, updated_at) FROM '$$PATH$$/3895.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3961.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3947.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3945.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3988.dat';

--
-- Data for Name: exam; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.exam (exam_id, exam_series_id, name, total_part, total_question, total_comment, point_reward, nums_join, hashtag, is_full_explanation, audio, duration, file_download, created_at, updated_at) FROM stdin;
\.
COPY public.exam (exam_id, exam_series_id, name, total_part, total_question, total_comment, point_reward, nums_join, hashtag, is_full_explanation, audio, duration, file_download, created_at, updated_at) FROM '$$PATH$$/3927.dat';

--
-- Data for Name: exam_series; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.exam_series (exam_series_id, name, total_exam, public_date, author, created_by, created_at, updated_at) FROM stdin;
\.
COPY public.exam_series (exam_series_id, name, total_exam, public_date, author, created_by, created_at, updated_at) FROM '$$PATH$$/3925.dat';

--
-- Data for Name: exam_taking; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.exam_taking (exam_taking_id, exam_id, user_id, time_finished, nums_of_correct_qn, total_question, created_at, updated_at) FROM stdin;
\.
COPY public.exam_taking (exam_taking_id, exam_id, user_id, time_finished, nums_of_correct_qn, total_question, created_at, updated_at) FROM '$$PATH$$/3941.dat';

--
-- Data for Name: flashcard; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.flashcard (fc_id, fc_set_id, word, meaning, type_of_word, pronounce, audio, example, note, image, created_by, created_at, updated_at) FROM stdin;
\.
COPY public.flashcard (fc_id, fc_set_id, word, meaning, type_of_word, pronounce, audio, example, note, image, created_by, created_at, updated_at) FROM '$$PATH$$/3920.dat';

--
-- Data for Name: flashcard_set; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.flashcard_set (fc_set_id, fc_type_id, name, description, words_count, system_belong, access, views, created_by, created_at, updated_at) FROM stdin;
\.
COPY public.flashcard_set (fc_set_id, fc_type_id, name, description, words_count, system_belong, access, views, created_by, created_at, updated_at) FROM '$$PATH$$/3918.dat';

--
-- Data for Name: flashcard_share_permit; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.flashcard_share_permit (user_id, fc_set_id, created_at) FROM stdin;
\.
COPY public.flashcard_share_permit (user_id, fc_set_id, created_at) FROM '$$PATH$$/3922.dat';

--
-- Data for Name: flashcard_type; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.flashcard_type (fc_type_id, type, description, sets_count, created_at, updated_at) FROM stdin;
\.
COPY public.flashcard_type (fc_type_id, type, description, sets_count, created_at, updated_at) FROM '$$PATH$$/3916.dat';

--
-- Data for Name: hashtag; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.hashtag (hashtag_id, name, created_at, updated_at) FROM stdin;
\.
COPY public.hashtag (hashtag_id, name, created_at, updated_at) FROM '$$PATH$$/3931.dat';

--
-- Data for Name: join_course; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.join_course (student_id, course_id, created_at) FROM stdin;
\.
COPY public.join_course (student_id, course_id, created_at) FROM '$$PATH$$/3902.dat';

--
-- Data for Name: join_lesson; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.join_lesson (student_id, lesson_id, created_at) FROM stdin;
\.
COPY public.join_lesson (student_id, lesson_id, created_at) FROM '$$PATH$$/3903.dat';

--
-- Data for Name: learnt_list; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.learnt_list (fc_id, user_id, created_at) FROM stdin;
\.
COPY public.learnt_list (fc_id, user_id, created_at) FROM '$$PATH$$/3921.dat';

--
-- Data for Name: lesson; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.lesson (lesson_id, unit_id, numeric_order, name, type, video_url, video_time, flashcard_set_id, text, description, created_at, updated_at) FROM stdin;
\.
COPY public.lesson (lesson_id, unit_id, numeric_order, name, type, video_url, video_time, flashcard_set_id, text, description, created_at, updated_at) FROM '$$PATH$$/3901.dat';

--
-- Data for Name: like; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public."like" (user_id, comment_id, created_at) FROM stdin;
\.
COPY public."like" (user_id, comment_id, created_at) FROM '$$PATH$$/3923.dat';

--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.likes (user_id, comment_id, created_at) FROM stdin;
\.
COPY public.likes (user_id, comment_id, created_at) FROM '$$PATH$$/3914.dat';

--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.note (note_id, student_id, lesson_id, note, created_at, updated_at) FROM stdin;
\.
COPY public.note (note_id, student_id, lesson_id, note, created_at, updated_at) FROM '$$PATH$$/3905.dat';

--
-- Data for Name: part; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.part (part_id, exam_id, name, total_question, number_of_explanation, numeric_order, created_at, updated_at) FROM stdin;
\.
COPY public.part (part_id, exam_id, name, total_question, number_of_explanation, numeric_order, created_at, updated_at) FROM '$$PATH$$/3929.dat';

--
-- Data for Name: part_option; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.part_option (exam_taking_id, part_id, created_at, updated_at) FROM stdin;
\.
COPY public.part_option (exam_taking_id, part_id, created_at, updated_at) FROM '$$PATH$$/3943.dat';

--
-- Data for Name: question; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.question (question_id, set_question_id, hashtag_id, name, explain, order_qn, level, created_at, updated_at) FROM stdin;
\.
COPY public.question (question_id, set_question_id, hashtag_id, name, explain, order_qn, level, created_at, updated_at) FROM '$$PATH$$/3935.dat';

--
-- Data for Name: rank; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.rank (rank_id, rank_name, point_to_unlock, created_at, updated_at) FROM stdin;
\.
COPY public.rank (rank_id, rank_name, point_to_unlock, created_at, updated_at) FROM '$$PATH$$/3891.dat';

--
-- Data for Name: rating; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.rating (student_id, course_id, rate, created_at, updated_at) FROM stdin;
\.
COPY public.rating (student_id, course_id, rate, created_at, updated_at) FROM '$$PATH$$/3906.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.roles (role_id, role_name, created_at, updated_at) FROM stdin;
\.
COPY public.roles (role_id, role_name, created_at, updated_at) FROM '$$PATH$$/3910.dat';

--
-- Data for Name: set_question; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.set_question (set_question_id, part_id, title, numeric_order, audio, created_at, updated_at) FROM stdin;
\.
COPY public.set_question (set_question_id, part_id, title, numeric_order, audio, created_at, updated_at) FROM '$$PATH$$/3933.dat';

--
-- Data for Name: side; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.side (side_id, set_question_id, paragraph, seq, created_at, updated_at) FROM stdin;
\.
COPY public.side (side_id, set_question_id, paragraph, seq, created_at, updated_at) FROM '$$PATH$$/3939.dat';

--
-- Data for Name: slide; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.slide (slide_id, sequence, lesson_id, text, created_at, updated_at) FROM stdin;
\.
COPY public.slide (slide_id, sequence, lesson_id, text, created_at, updated_at) FROM '$$PATH$$/3913.dat';

--
-- Data for Name: unit; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.unit (unit_id, chapter_id, numeric_order, name, total_lesson, created_at, updated_at) FROM stdin;
\.
COPY public.unit (unit_id, chapter_id, numeric_order, name, total_lesson, created_at, updated_at) FROM '$$PATH$$/3899.dat';

--
-- Data for Name: user_to_role; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.user_to_role (user_id, role_id, created_at, updated_at) FROM stdin;
\.
COPY public.user_to_role (user_id, role_id, created_at, updated_at) FROM '$$PATH$$/3911.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: examify_pxac_user
--

COPY public.users (user_id, mail, password, first_name, last_name, date_of_birth, phone_number, avt, banner, description, rank_id, accumulated_point, rank_point, refresh_token, created_at, updated_at) FROM stdin;
\.
COPY public.users (user_id, mail, password, first_name, last_name, date_of_birth, phone_number, avt, banner, description, rank_id, accumulated_point, rank_point, refresh_token, created_at, updated_at) FROM '$$PATH$$/3893.dat';

--
-- Name: api_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_address_id_seq', 1, true);


--
-- Name: api_cartitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_cartitem_id_seq', 2, true);


--
-- Name: api_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_category_id_seq', 8, true);


--
-- Name: api_favoriteitem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_favoriteitem_id_seq', 2, true);


--
-- Name: api_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_order_id_seq', 1, true);


--
-- Name: api_orderdetail_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_orderdetail_id_seq', 1, true);


--
-- Name: api_payment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_payment_id_seq', 1, true);


--
-- Name: api_paymentprovider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_paymentprovider_id_seq', 6, true);


--
-- Name: api_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_product_id_seq', 49, true);


--
-- Name: api_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_review_id_seq', 1, false);


--
-- Name: api_usedvoucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_usedvoucher_id_seq', 1, false);


--
-- Name: api_variation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_variation_id_seq', 174, true);


--
-- Name: api_voucher_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.api_voucher_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 76, true);


--
-- Name: authentication_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.authentication_user_groups_id_seq', 1, false);


--
-- Name: authentication_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.authentication_user_id_seq', 4, true);


--
-- Name: authentication_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.authentication_user_user_permissions_id_seq', 1, false);


--
-- Name: chapter_chapter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.chapter_chapter_id_seq', 100, true);


--
-- Name: choice_choice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.choice_choice_id_seq', 775, true);


--
-- Name: comment_comment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.comment_comment_id_seq', 1, false);


--
-- Name: course_course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.course_course_id_seq', 30, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 19, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 65, true);


--
-- Name: exam_exam_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.exam_exam_id_seq', 12, true);


--
-- Name: exam_series_exam_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.exam_series_exam_series_id_seq', 2, true);


--
-- Name: exam_taking_exam_taking_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.exam_taking_exam_taking_id_seq', 1, true);


--
-- Name: flashcard_fc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.flashcard_fc_id_seq', 200, true);


--
-- Name: flashcard_set_fc_set_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.flashcard_set_fc_set_id_seq', 20, true);


--
-- Name: flashcard_type_fc_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.flashcard_type_fc_type_id_seq', 3, true);


--
-- Name: hashtag_hashtag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.hashtag_hashtag_id_seq', 61, true);


--
-- Name: lesson_lesson_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.lesson_lesson_id_seq', 300, true);


--
-- Name: note_note_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.note_note_id_seq', 50, true);


--
-- Name: part_part_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.part_part_id_seq', 7, true);


--
-- Name: question_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.question_question_id_seq', 200, true);


--
-- Name: rank_rank_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.rank_rank_id_seq', 9, true);


--
-- Name: roles_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.roles_role_id_seq', 1, false);


--
-- Name: set_question_set_question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.set_question_set_question_id_seq', 103, true);


--
-- Name: side_side_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.side_side_id_seq', 92, true);


--
-- Name: slide_slide_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.slide_slide_id_seq', 100, true);


--
-- Name: unit_unit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.unit_unit_id_seq', 200, true);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: examify_pxac_user
--

SELECT pg_catalog.setval('public.users_user_id_seq', 21, true);


--
-- Name: answer_record answer_record_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.answer_record
    ADD CONSTRAINT answer_record_pkey PRIMARY KEY (exam_taking_id, question_id);


--
-- Name: api_address api_address_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_address
    ADD CONSTRAINT api_address_pkey PRIMARY KEY (id);


--
-- Name: api_cartitem api_cartitem_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_cartitem
    ADD CONSTRAINT api_cartitem_pkey PRIMARY KEY (id);


--
-- Name: api_category api_category_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_category
    ADD CONSTRAINT api_category_pkey PRIMARY KEY (id);


--
-- Name: api_favoriteitem api_favoriteitem_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_favoriteitem
    ADD CONSTRAINT api_favoriteitem_pkey PRIMARY KEY (id);


--
-- Name: api_order api_order_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_order
    ADD CONSTRAINT api_order_pkey PRIMARY KEY (id);


--
-- Name: api_orderdetail api_orderdetail_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_orderdetail
    ADD CONSTRAINT api_orderdetail_pkey PRIMARY KEY (id);


--
-- Name: api_payment api_payment_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_payment
    ADD CONSTRAINT api_payment_pkey PRIMARY KEY (id);


--
-- Name: api_paymentprovider api_paymentprovider_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_paymentprovider
    ADD CONSTRAINT api_paymentprovider_pkey PRIMARY KEY (id);


--
-- Name: api_product api_product_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_product
    ADD CONSTRAINT api_product_pkey PRIMARY KEY (id);


--
-- Name: api_review api_review_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_review
    ADD CONSTRAINT api_review_pkey PRIMARY KEY (id);


--
-- Name: api_usedvoucher api_usedvoucher_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_usedvoucher
    ADD CONSTRAINT api_usedvoucher_pkey PRIMARY KEY (id);


--
-- Name: api_variation api_variation_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_variation
    ADD CONSTRAINT api_variation_pkey PRIMARY KEY (id);


--
-- Name: api_voucher api_voucher_code_cd873620_uniq; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_voucher
    ADD CONSTRAINT api_voucher_code_cd873620_uniq UNIQUE (code);


--
-- Name: api_voucher api_voucher_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_voucher
    ADD CONSTRAINT api_voucher_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authentication_user authentication_user_email_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user
    ADD CONSTRAINT authentication_user_email_key UNIQUE (email);


--
-- Name: authentication_user_groups authentication_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_groups
    ADD CONSTRAINT authentication_user_groups_pkey PRIMARY KEY (id);


--
-- Name: authentication_user_groups authentication_user_groups_user_id_group_id_8af031ac_uniq; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_groups
    ADD CONSTRAINT authentication_user_groups_user_id_group_id_8af031ac_uniq UNIQUE (user_id, group_id);


--
-- Name: authentication_user authentication_user_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user
    ADD CONSTRAINT authentication_user_pkey PRIMARY KEY (id);


--
-- Name: authentication_user_user_permissions authentication_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_user_permissions
    ADD CONSTRAINT authentication_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: authentication_user_user_permissions authentication_user_user_user_id_permission_id_ec51b09f_uniq; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_user_permissions
    ADD CONSTRAINT authentication_user_user_user_id_permission_id_ec51b09f_uniq UNIQUE (user_id, permission_id);


--
-- Name: chapter chapter_course_id_numeric_order_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.chapter
    ADD CONSTRAINT chapter_course_id_numeric_order_key UNIQUE (course_id, numeric_order);


--
-- Name: chapter chapter_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.chapter
    ADD CONSTRAINT chapter_pkey PRIMARY KEY (chapter_id);


--
-- Name: choice choice_order_choice_question_id_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.choice
    ADD CONSTRAINT choice_order_choice_question_id_key UNIQUE (order_choice, question_id);


--
-- Name: choice choice_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.choice
    ADD CONSTRAINT choice_pkey PRIMARY KEY (choice_id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (comment_id);


--
-- Name: course course_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_pkey PRIMARY KEY (course_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: exam exam_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam
    ADD CONSTRAINT exam_pkey PRIMARY KEY (exam_id);


--
-- Name: exam_series exam_series_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam_series
    ADD CONSTRAINT exam_series_pkey PRIMARY KEY (exam_series_id);


--
-- Name: exam_taking exam_taking_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam_taking
    ADD CONSTRAINT exam_taking_pkey PRIMARY KEY (exam_taking_id);


--
-- Name: flashcard flashcard_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard
    ADD CONSTRAINT flashcard_pkey PRIMARY KEY (fc_id);


--
-- Name: flashcard_set flashcard_set_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_set
    ADD CONSTRAINT flashcard_set_pkey PRIMARY KEY (fc_set_id);


--
-- Name: flashcard_share_permit flashcard_share_permit_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_share_permit
    ADD CONSTRAINT flashcard_share_permit_pkey PRIMARY KEY (user_id, fc_set_id);


--
-- Name: flashcard_type flashcard_type_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_type
    ADD CONSTRAINT flashcard_type_pkey PRIMARY KEY (fc_type_id);


--
-- Name: hashtag hashtag_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.hashtag
    ADD CONSTRAINT hashtag_pkey PRIMARY KEY (hashtag_id);


--
-- Name: join_course join_course_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.join_course
    ADD CONSTRAINT join_course_pkey PRIMARY KEY (student_id, course_id);


--
-- Name: join_lesson join_lesson_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.join_lesson
    ADD CONSTRAINT join_lesson_pkey PRIMARY KEY (student_id, lesson_id);


--
-- Name: learnt_list learnt_list_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.learnt_list
    ADD CONSTRAINT learnt_list_pkey PRIMARY KEY (fc_id, user_id);


--
-- Name: lesson lesson_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.lesson
    ADD CONSTRAINT lesson_pkey PRIMARY KEY (lesson_id);


--
-- Name: lesson lesson_unit_id_numeric_order_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.lesson
    ADD CONSTRAINT lesson_unit_id_numeric_order_key UNIQUE (unit_id, numeric_order);


--
-- Name: like like_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public."like"
    ADD CONSTRAINT like_pkey PRIMARY KEY (user_id, comment_id);


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (user_id, comment_id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (note_id);


--
-- Name: part part_numeric_order_exam_id_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.part
    ADD CONSTRAINT part_numeric_order_exam_id_key UNIQUE (numeric_order, exam_id);


--
-- Name: part_option part_option_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.part_option
    ADD CONSTRAINT part_option_pkey PRIMARY KEY (exam_taking_id, part_id);


--
-- Name: part part_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.part
    ADD CONSTRAINT part_pkey PRIMARY KEY (part_id);


--
-- Name: question question_order_qn_set_question_id_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_order_qn_set_question_id_key UNIQUE (order_qn, set_question_id);


--
-- Name: question question_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_pkey PRIMARY KEY (question_id);


--
-- Name: rank rank_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.rank
    ADD CONSTRAINT rank_pkey PRIMARY KEY (rank_id);


--
-- Name: rating rating_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT rating_pkey PRIMARY KEY (student_id, course_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (role_id);


--
-- Name: set_question set_question_part_id_numeric_order_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.set_question
    ADD CONSTRAINT set_question_part_id_numeric_order_key UNIQUE (part_id, numeric_order);


--
-- Name: set_question set_question_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.set_question
    ADD CONSTRAINT set_question_pkey PRIMARY KEY (set_question_id);


--
-- Name: side side_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.side
    ADD CONSTRAINT side_pkey PRIMARY KEY (side_id);


--
-- Name: side side_seq_set_question_id_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.side
    ADD CONSTRAINT side_seq_set_question_id_key UNIQUE (seq, set_question_id);


--
-- Name: slide slide_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.slide
    ADD CONSTRAINT slide_pkey PRIMARY KEY (slide_id);


--
-- Name: slide slide_sequence_lesson_id_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.slide
    ADD CONSTRAINT slide_sequence_lesson_id_key UNIQUE (sequence, lesson_id);


--
-- Name: unit unit_chapter_id_numeric_order_key; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.unit
    ADD CONSTRAINT unit_chapter_id_numeric_order_key UNIQUE (chapter_id, numeric_order);


--
-- Name: unit unit_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.unit
    ADD CONSTRAINT unit_pkey PRIMARY KEY (unit_id);


--
-- Name: user_to_role user_to_role_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.user_to_role
    ADD CONSTRAINT user_to_role_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: api_address_created_by_id_2ab20509; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_address_created_by_id_2ab20509 ON public.api_address USING btree (created_by_id);


--
-- Name: api_cartitem_created_by_id_722c65d0; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_cartitem_created_by_id_722c65d0 ON public.api_cartitem USING btree (created_by_id);


--
-- Name: api_cartitem_product_id_4699c5ae; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_cartitem_product_id_4699c5ae ON public.api_cartitem USING btree (product_id);


--
-- Name: api_cartitem_variation_id_542062f8; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_cartitem_variation_id_542062f8 ON public.api_cartitem USING btree (variation_id);


--
-- Name: api_favoriteitem_created_by_id_4e2d2705; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_favoriteitem_created_by_id_4e2d2705 ON public.api_favoriteitem USING btree (created_by_id);


--
-- Name: api_favoriteitem_product_id_69a6bf45; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_favoriteitem_product_id_69a6bf45 ON public.api_favoriteitem USING btree (product_id);


--
-- Name: api_order_created_by_id_408791c2; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_order_created_by_id_408791c2 ON public.api_order USING btree (created_by_id);


--
-- Name: api_order_voucher_id_d86e2daa; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_order_voucher_id_d86e2daa ON public.api_order USING btree (voucher_id);


--
-- Name: api_orderdetail_order_id_8651abdc; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_orderdetail_order_id_8651abdc ON public.api_orderdetail USING btree (order_id);


--
-- Name: api_orderdetail_product_id_1bc6f0ff; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_orderdetail_product_id_1bc6f0ff ON public.api_orderdetail USING btree (product_id);


--
-- Name: api_orderdetail_variation_id_def322b9; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_orderdetail_variation_id_def322b9 ON public.api_orderdetail USING btree (variation_id);


--
-- Name: api_payment_created_by_id_6e421157; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_payment_created_by_id_6e421157 ON public.api_payment USING btree (created_by_id);


--
-- Name: api_payment_provider_id_ffd2cdff; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_payment_provider_id_ffd2cdff ON public.api_payment USING btree (provider_id);


--
-- Name: api_product_category_id_a2b9d1e7; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_product_category_id_a2b9d1e7 ON public.api_product USING btree (category_id);


--
-- Name: api_review_created_by_id_48eceffb; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_review_created_by_id_48eceffb ON public.api_review USING btree (created_by_id);


--
-- Name: api_review_product_id_78d61c8d; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_review_product_id_78d61c8d ON public.api_review USING btree (product_id);


--
-- Name: api_review_variation_id_d75f4993; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_review_variation_id_d75f4993 ON public.api_review USING btree (variation_id);


--
-- Name: api_usedvoucher_user_id_715c010d; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_usedvoucher_user_id_715c010d ON public.api_usedvoucher USING btree (user_id);


--
-- Name: api_usedvoucher_voucher_id_5ab1808f; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_usedvoucher_voucher_id_5ab1808f ON public.api_usedvoucher USING btree (voucher_id);


--
-- Name: api_variation_product_id_e7532f50; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_variation_product_id_e7532f50 ON public.api_variation USING btree (product_id);


--
-- Name: api_voucher_code_cd873620_like; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX api_voucher_code_cd873620_like ON public.api_voucher USING btree (code varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authentication_user_email_2220eff5_like; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX authentication_user_email_2220eff5_like ON public.authentication_user USING btree (email varchar_pattern_ops);


--
-- Name: authentication_user_groups_group_id_6b5c44b7; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX authentication_user_groups_group_id_6b5c44b7 ON public.authentication_user_groups USING btree (group_id);


--
-- Name: authentication_user_groups_user_id_30868577; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX authentication_user_groups_user_id_30868577 ON public.authentication_user_groups USING btree (user_id);


--
-- Name: authentication_user_user_permissions_permission_id_ea6be19a; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX authentication_user_user_permissions_permission_id_ea6be19a ON public.authentication_user_user_permissions USING btree (permission_id);


--
-- Name: authentication_user_user_permissions_user_id_736ebf7e; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX authentication_user_user_permissions_user_id_736ebf7e ON public.authentication_user_user_permissions USING btree (user_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: examify_pxac_user
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: users auto_create_user_to_role; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER auto_create_user_to_role AFTER INSERT ON public.users FOR EACH ROW EXECUTE FUNCTION public.fn_create_a_role_user();


--
-- Name: chapter auto_numeric_order_chapter; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER auto_numeric_order_chapter AFTER DELETE ON public.chapter FOR EACH ROW EXECUTE FUNCTION public.fn_update_numeric_order_chapter();


--
-- Name: lesson auto_numeric_order_lesson; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER auto_numeric_order_lesson AFTER DELETE ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.fn_update_numeric_order_lesson();


--
-- Name: unit auto_numeric_order_unit; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER auto_numeric_order_unit AFTER DELETE ON public.unit FOR EACH ROW EXECUTE FUNCTION public.fn_update_numeric_order_unit();


--
-- Name: chapter create_chapter; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER create_chapter AFTER INSERT ON public.chapter FOR EACH ROW EXECUTE FUNCTION public.increase_total_chapter();


--
-- Name: lesson create_lesson_video; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER create_lesson_video AFTER INSERT ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.increase_total_video_course();


--
-- Name: exam create_new_exam; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER create_new_exam AFTER INSERT ON public.exam FOR EACH ROW EXECUTE FUNCTION public.increase_total_exam();


--
-- Name: lesson create_new_lesson; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER create_new_lesson AFTER INSERT ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.increase_total_lesson();


--
-- Name: rating create_rating_course; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER create_rating_course AFTER INSERT ON public.rating FOR EACH ROW EXECUTE FUNCTION public.fn_create_update_rating_course();


--
-- Name: chapter delete_chapter; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER delete_chapter AFTER DELETE ON public.chapter FOR EACH ROW EXECUTE FUNCTION public.decrease_total_chapter();


--
-- Name: exam delete_exam; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER delete_exam AFTER DELETE ON public.exam FOR EACH ROW EXECUTE FUNCTION public.decrease_total_exam();


--
-- Name: lesson delete_lesson; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER delete_lesson AFTER DELETE ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.decrease_total_lesson();


--
-- Name: lesson delete_lesson_video; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER delete_lesson_video AFTER DELETE ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.decrease_total_video_course();


--
-- Name: rating delete_rating_course; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER delete_rating_course AFTER DELETE ON public.rating FOR EACH ROW EXECUTE FUNCTION public.fn_delete_rating_course();


--
-- Name: part numeric_order_part_delete; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER numeric_order_part_delete AFTER DELETE ON public.part FOR EACH ROW EXECUTE FUNCTION public.fn_num_order_part_delete();


--
-- Name: part numeric_order_part_update; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER numeric_order_part_update AFTER UPDATE OF numeric_order ON public.part FOR EACH ROW WHEN ((pg_trigger_depth() = 0)) EXECUTE FUNCTION public.fn_num_order_part_update();


--
-- Name: question numeric_order_question_delete; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER numeric_order_question_delete AFTER DELETE ON public.question FOR EACH ROW EXECUTE FUNCTION public.fn_num_order_question_delete();


--
-- Name: set_question numeric_order_set_question_delete; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER numeric_order_set_question_delete AFTER DELETE ON public.set_question FOR EACH ROW EXECUTE FUNCTION public.fn_num_order_set_question_delete();


--
-- Name: set_question numeric_order_set_question_update; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER numeric_order_set_question_update AFTER UPDATE OF numeric_order ON public.set_question FOR EACH ROW WHEN ((pg_trigger_depth() = 0)) EXECUTE FUNCTION public.fn_num_order_set_question_update();


--
-- Name: side numeric_order_side_delete; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER numeric_order_side_delete AFTER DELETE ON public.side FOR EACH ROW EXECUTE FUNCTION public.fn_num_order_side_delete();


--
-- Name: side numeric_order_side_update; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER numeric_order_side_update AFTER UPDATE OF seq ON public.side FOR EACH ROW WHEN ((pg_trigger_depth() = 0)) EXECUTE FUNCTION public.fn_num_order_side_update();


--
-- Name: answer_record update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.answer_record FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: chapter update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.chapter FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: choice update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.choice FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: comment update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.comment FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: course update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.course FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: exam update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.exam FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: exam_series update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.exam_series FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: exam_taking update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.exam_taking FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: flashcard update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.flashcard FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: flashcard_set update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.flashcard_set FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: flashcard_type update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.flashcard_type FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: hashtag update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.hashtag FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: lesson update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: note update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.note FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: part update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.part FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: part_option update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.part_option FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: question update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.question FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: rank update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.rank FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: rating update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.rating FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: roles update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.roles FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: set_question update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.set_question FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: side update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.side FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: slide update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.slide FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: unit update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.unit FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: user_to_role update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.user_to_role FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: users update_db_timestamp; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_db_timestamp BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_timestamp();


--
-- Name: part update_decrement_total_part_exam; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_decrement_total_part_exam AFTER DELETE ON public.part FOR EACH ROW EXECUTE FUNCTION public.fn_decrease_total_part_exam();


--
-- Name: question update_decrement_total_question_exam; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_decrement_total_question_exam AFTER DELETE ON public.question FOR EACH ROW EXECUTE FUNCTION public.fn_decrease_total_question_exam();


--
-- Name: question update_decrement_total_question_part; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_decrement_total_question_part AFTER DELETE ON public.question FOR EACH ROW EXECUTE FUNCTION public.fn_decrease_total_question_part();


--
-- Name: part update_increment_total_part_exam; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_increment_total_part_exam AFTER INSERT ON public.part FOR EACH ROW EXECUTE FUNCTION public.fn_increase_total_part_exam();


--
-- Name: question update_increment_total_question_exam; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_increment_total_question_exam AFTER INSERT ON public.question FOR EACH ROW EXECUTE FUNCTION public.fn_increase_total_question_exam();


--
-- Name: question update_increment_total_question_part; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_increment_total_question_part AFTER INSERT ON public.question FOR EACH ROW EXECUTE FUNCTION public.fn_increase_total_question_part();


--
-- Name: lesson update_lesson_unit_id; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_lesson_unit_id BEFORE UPDATE OF unit_id ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.update_total_lesson();


--
-- Name: exam_taking update_nums_join_exam; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_nums_join_exam AFTER INSERT ON public.exam_taking FOR EACH ROW EXECUTE FUNCTION public.fn_increase_nums_join_exam();


--
-- Name: join_course update_participants_course; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_participants_course AFTER INSERT ON public.join_course FOR EACH ROW EXECUTE FUNCTION public.fn_increase_participants_course();


--
-- Name: rating update_rating_course; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_rating_course AFTER UPDATE OF rate ON public.rating FOR EACH ROW EXECUTE FUNCTION public.fn_create_update_rating_course();


--
-- Name: api_review update_reviews_stat_trigger; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_reviews_stat_trigger AFTER INSERT OR DELETE ON public.api_review FOR EACH ROW EXECUTE FUNCTION public.update_reviews_stat();


--
-- Name: flashcard_set update_sets_count_trigger; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_sets_count_trigger AFTER INSERT OR DELETE ON public.flashcard_set FOR EACH ROW EXECUTE FUNCTION public.update_sets_count();


--
-- Name: api_variation update_variations_count_trigger; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_variations_count_trigger AFTER INSERT OR DELETE ON public.api_variation FOR EACH ROW EXECUTE FUNCTION public.update_variations_count();


--
-- Name: lesson update_video_time_lesson; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_video_time_lesson AFTER UPDATE OF video_time ON public.lesson FOR EACH ROW EXECUTE FUNCTION public.update_total_video_course();


--
-- Name: flashcard update_words_count_trigger; Type: TRIGGER; Schema: public; Owner: examify_pxac_user
--

CREATE TRIGGER update_words_count_trigger AFTER INSERT OR DELETE ON public.flashcard FOR EACH ROW EXECUTE FUNCTION public.update_words_count();


--
-- Name: answer_record answer_record_choice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.answer_record
    ADD CONSTRAINT answer_record_choice_id_fkey FOREIGN KEY (choice_id) REFERENCES public.choice(choice_id);


--
-- Name: answer_record answer_record_exam_taking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.answer_record
    ADD CONSTRAINT answer_record_exam_taking_id_fkey FOREIGN KEY (exam_taking_id) REFERENCES public.exam_taking(exam_taking_id);


--
-- Name: answer_record answer_record_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.answer_record
    ADD CONSTRAINT answer_record_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.question(question_id);


--
-- Name: api_address api_address_created_by_id_2ab20509_fk_authentication_user_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_address
    ADD CONSTRAINT api_address_created_by_id_2ab20509_fk_authentication_user_id FOREIGN KEY (created_by_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_cartitem api_cartitem_created_by_id_722c65d0_fk_authentication_user_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_cartitem
    ADD CONSTRAINT api_cartitem_created_by_id_722c65d0_fk_authentication_user_id FOREIGN KEY (created_by_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_cartitem api_cartitem_product_id_4699c5ae_fk_api_product_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_cartitem
    ADD CONSTRAINT api_cartitem_product_id_4699c5ae_fk_api_product_id FOREIGN KEY (product_id) REFERENCES public.api_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_cartitem api_cartitem_variation_id_542062f8_fk_api_variation_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_cartitem
    ADD CONSTRAINT api_cartitem_variation_id_542062f8_fk_api_variation_id FOREIGN KEY (variation_id) REFERENCES public.api_variation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_favoriteitem api_favoriteitem_created_by_id_4e2d2705_fk_authentic; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_favoriteitem
    ADD CONSTRAINT api_favoriteitem_created_by_id_4e2d2705_fk_authentic FOREIGN KEY (created_by_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_favoriteitem api_favoriteitem_product_id_69a6bf45_fk_api_product_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_favoriteitem
    ADD CONSTRAINT api_favoriteitem_product_id_69a6bf45_fk_api_product_id FOREIGN KEY (product_id) REFERENCES public.api_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_order api_order_created_by_id_408791c2_fk_authentication_user_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_order
    ADD CONSTRAINT api_order_created_by_id_408791c2_fk_authentication_user_id FOREIGN KEY (created_by_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_order api_order_voucher_id_d86e2daa_fk_api_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_order
    ADD CONSTRAINT api_order_voucher_id_d86e2daa_fk_api_voucher_id FOREIGN KEY (voucher_id) REFERENCES public.api_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_orderdetail api_orderdetail_order_id_8651abdc_fk_api_order_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_orderdetail
    ADD CONSTRAINT api_orderdetail_order_id_8651abdc_fk_api_order_id FOREIGN KEY (order_id) REFERENCES public.api_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_orderdetail api_orderdetail_product_id_1bc6f0ff_fk_api_product_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_orderdetail
    ADD CONSTRAINT api_orderdetail_product_id_1bc6f0ff_fk_api_product_id FOREIGN KEY (product_id) REFERENCES public.api_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_orderdetail api_orderdetail_variation_id_def322b9_fk_api_variation_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_orderdetail
    ADD CONSTRAINT api_orderdetail_variation_id_def322b9_fk_api_variation_id FOREIGN KEY (variation_id) REFERENCES public.api_variation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_payment api_payment_created_by_id_6e421157_fk_authentication_user_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_payment
    ADD CONSTRAINT api_payment_created_by_id_6e421157_fk_authentication_user_id FOREIGN KEY (created_by_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_payment api_payment_provider_id_ffd2cdff_fk_api_paymentprovider_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_payment
    ADD CONSTRAINT api_payment_provider_id_ffd2cdff_fk_api_paymentprovider_id FOREIGN KEY (provider_id) REFERENCES public.api_paymentprovider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_product api_product_category_id_a2b9d1e7_fk_api_category_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_product
    ADD CONSTRAINT api_product_category_id_a2b9d1e7_fk_api_category_id FOREIGN KEY (category_id) REFERENCES public.api_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_review api_review_created_by_id_48eceffb_fk_authentication_user_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_review
    ADD CONSTRAINT api_review_created_by_id_48eceffb_fk_authentication_user_id FOREIGN KEY (created_by_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_review api_review_product_id_78d61c8d_fk_api_product_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_review
    ADD CONSTRAINT api_review_product_id_78d61c8d_fk_api_product_id FOREIGN KEY (product_id) REFERENCES public.api_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_review api_review_variation_id_d75f4993_fk_api_variation_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_review
    ADD CONSTRAINT api_review_variation_id_d75f4993_fk_api_variation_id FOREIGN KEY (variation_id) REFERENCES public.api_variation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_usedvoucher api_usedvoucher_user_id_715c010d_fk_authentication_user_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_usedvoucher
    ADD CONSTRAINT api_usedvoucher_user_id_715c010d_fk_authentication_user_id FOREIGN KEY (user_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_usedvoucher api_usedvoucher_voucher_id_5ab1808f_fk_api_voucher_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_usedvoucher
    ADD CONSTRAINT api_usedvoucher_voucher_id_5ab1808f_fk_api_voucher_id FOREIGN KEY (voucher_id) REFERENCES public.api_voucher(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_variation api_variation_product_id_e7532f50_fk_api_product_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.api_variation
    ADD CONSTRAINT api_variation_product_id_e7532f50_fk_api_product_id FOREIGN KEY (product_id) REFERENCES public.api_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentication_user_user_permissions authentication_user__permission_id_ea6be19a_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_user_permissions
    ADD CONSTRAINT authentication_user__permission_id_ea6be19a_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentication_user_groups authentication_user__user_id_30868577_fk_authentic; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_groups
    ADD CONSTRAINT authentication_user__user_id_30868577_fk_authentic FOREIGN KEY (user_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentication_user_user_permissions authentication_user__user_id_736ebf7e_fk_authentic; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_user_permissions
    ADD CONSTRAINT authentication_user__user_id_736ebf7e_fk_authentic FOREIGN KEY (user_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authentication_user_groups authentication_user_groups_group_id_6b5c44b7_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.authentication_user_groups
    ADD CONSTRAINT authentication_user_groups_group_id_6b5c44b7_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: chapter chapter_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.chapter
    ADD CONSTRAINT chapter_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id);


--
-- Name: choice choice_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.choice
    ADD CONSTRAINT choice_question_id_fkey FOREIGN KEY (question_id) REFERENCES public.question(question_id);


--
-- Name: comment comment_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id);


--
-- Name: comment comment_respond_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_respond_id_fkey FOREIGN KEY (respond_id) REFERENCES public.comment(comment_id);


--
-- Name: comment comment_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(user_id);


--
-- Name: course course_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.course
    ADD CONSTRAINT course_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_authentication_user_id; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_authentication_user_id FOREIGN KEY (user_id) REFERENCES public.authentication_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: exam exam_exam_series_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam
    ADD CONSTRAINT exam_exam_series_id_fkey FOREIGN KEY (exam_series_id) REFERENCES public.exam_series(exam_series_id) ON DELETE CASCADE;


--
-- Name: exam_series exam_series_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam_series
    ADD CONSTRAINT exam_series_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id);


--
-- Name: exam_taking exam_taking_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam_taking
    ADD CONSTRAINT exam_taking_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exam(exam_id);


--
-- Name: exam_taking exam_taking_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.exam_taking
    ADD CONSTRAINT exam_taking_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: flashcard flashcard_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard
    ADD CONSTRAINT flashcard_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: flashcard flashcard_fc_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard
    ADD CONSTRAINT flashcard_fc_set_id_fkey FOREIGN KEY (fc_set_id) REFERENCES public.flashcard_set(fc_set_id) ON DELETE CASCADE;


--
-- Name: flashcard_set flashcard_set_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_set
    ADD CONSTRAINT flashcard_set_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: flashcard_set flashcard_set_fc_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_set
    ADD CONSTRAINT flashcard_set_fc_type_id_fkey FOREIGN KEY (fc_type_id) REFERENCES public.flashcard_type(fc_type_id) ON DELETE CASCADE;


--
-- Name: flashcard_share_permit flashcard_share_permit_fc_set_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_share_permit
    ADD CONSTRAINT flashcard_share_permit_fc_set_id_fkey FOREIGN KEY (fc_set_id) REFERENCES public.flashcard_set(fc_set_id) ON DELETE CASCADE;


--
-- Name: flashcard_share_permit flashcard_share_permit_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.flashcard_share_permit
    ADD CONSTRAINT flashcard_share_permit_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: join_course join_course_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.join_course
    ADD CONSTRAINT join_course_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id);


--
-- Name: join_course join_course_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.join_course
    ADD CONSTRAINT join_course_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(user_id);


--
-- Name: join_lesson join_lesson_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.join_lesson
    ADD CONSTRAINT join_lesson_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lesson(lesson_id);


--
-- Name: join_lesson join_lesson_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.join_lesson
    ADD CONSTRAINT join_lesson_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(user_id);


--
-- Name: learnt_list learnt_list_fc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.learnt_list
    ADD CONSTRAINT learnt_list_fc_id_fkey FOREIGN KEY (fc_id) REFERENCES public.flashcard(fc_id) ON DELETE CASCADE;


--
-- Name: learnt_list learnt_list_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.learnt_list
    ADD CONSTRAINT learnt_list_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: lesson lesson_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.lesson
    ADD CONSTRAINT lesson_unit_id_fkey FOREIGN KEY (unit_id) REFERENCES public.unit(unit_id);


--
-- Name: like like_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public."like"
    ADD CONSTRAINT like_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comment(comment_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: like like_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public."like"
    ADD CONSTRAINT like_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: likes likes_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.comment(comment_id);


--
-- Name: likes likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: note note_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lesson(lesson_id);


--
-- Name: note note_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(user_id);


--
-- Name: part part_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.part
    ADD CONSTRAINT part_exam_id_fkey FOREIGN KEY (exam_id) REFERENCES public.exam(exam_id);


--
-- Name: part_option part_option_exam_taking_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.part_option
    ADD CONSTRAINT part_option_exam_taking_id_fkey FOREIGN KEY (exam_taking_id) REFERENCES public.exam_taking(exam_taking_id);


--
-- Name: part_option part_option_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.part_option
    ADD CONSTRAINT part_option_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.part(part_id);


--
-- Name: question question_hashtag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_hashtag_id_fkey FOREIGN KEY (hashtag_id) REFERENCES public.hashtag(hashtag_id);


--
-- Name: question question_set_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.question
    ADD CONSTRAINT question_set_question_id_fkey FOREIGN KEY (set_question_id) REFERENCES public.set_question(set_question_id);


--
-- Name: rating rating_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT rating_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.course(course_id);


--
-- Name: rating rating_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.rating
    ADD CONSTRAINT rating_student_id_fkey FOREIGN KEY (student_id) REFERENCES public.users(user_id);


--
-- Name: set_question set_question_part_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.set_question
    ADD CONSTRAINT set_question_part_id_fkey FOREIGN KEY (part_id) REFERENCES public.part(part_id);


--
-- Name: side side_set_question_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.side
    ADD CONSTRAINT side_set_question_id_fkey FOREIGN KEY (set_question_id) REFERENCES public.set_question(set_question_id);


--
-- Name: slide slide_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.slide
    ADD CONSTRAINT slide_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.lesson(lesson_id);


--
-- Name: unit unit_chapter_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.unit
    ADD CONSTRAINT unit_chapter_id_fkey FOREIGN KEY (chapter_id) REFERENCES public.chapter(chapter_id);


--
-- Name: user_to_role user_to_role_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.user_to_role
    ADD CONSTRAINT user_to_role_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(role_id);


--
-- Name: user_to_role user_to_role_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.user_to_role
    ADD CONSTRAINT user_to_role_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: users users_rank_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: examify_pxac_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_rank_id_fkey FOREIGN KEY (rank_id) REFERENCES public.rank(rank_id);


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON SEQUENCES  TO examify_pxac_user;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TYPES  TO examify_pxac_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON FUNCTIONS  TO examify_pxac_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: -; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres GRANT ALL ON TABLES  TO examify_pxac_user;


--
-- PostgreSQL database dump complete
--

